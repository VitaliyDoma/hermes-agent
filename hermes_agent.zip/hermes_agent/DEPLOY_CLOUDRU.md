# Деплой Hermes на Cloud.ru (всё в одном контуре)

Цель: перенести агента на Cloud.ru, где уже есть LLM (Foundation Models). Сервер + агент + база — рядом.
Подключение — через веб-консоль Cloud.ru (терминал в браузере), без локального SSH.

## Шаг 1. Создать сервер (Evolution Compute)
1. Консоль Cloud.ru → меню (9 точек) → раздел **Evolution Compute** (Облачные серверы / Виртуальные машины).
2. **Создать** виртуальную машину:
   - ОС: **Ubuntu 24.04 LTS**.
   - Конфигурация: минимальная (для старта хватит 2 vCPU / 2–4 ГБ RAM). Если есть free-tier/бонусы — выбери его.
   - Сеть: включить **публичный IP** (чтобы дойти до VK/Telegram API).
   - Доступ: задать пароль root или SSH-ключ (запиши — понадобится для веб-консоли).
3. Создать и дождаться статуса «Активен».

## Шаг 2. Открыть веб-консоль
В карточке сервера → кнопка **«Консоль»** (откроется терминал в браузере). Войти под root.

## Шаг 3. Установить Docker (одна команда)
```bash
apt update && apt install -y docker.io docker-compose-plugin git nano && systemctl enable --now docker
```

## Шаг 4. Получить код агента
Вариант А — через GitHub (рекомендуется на будущее):
```bash
git clone <URL-твоего-репозитория> hermes && cd hermes
```
Вариант Б — без GitHub (загрузка архива):
1. Залей `hermes_agent.zip` в **Object Storage (S3)** Cloud.ru (или любой доступный URL).
2. На сервере:
```bash
apt install -y unzip
wget -O hermes.zip "<ссылка-на-zip>"
unzip hermes.zip && cd hermes_agent
```

## Шаг 5. Создать .env с ключом Cloud.ru
```bash
cp .env.example .env
nano .env
```
В `nano` впиши `LLM_API_KEY=<твой ключ ГЕРМЕС>` (тот же, что уже работает с Foundation Models),
сохрани: Ctrl+O, Enter, Ctrl+X. Остальные строки уже заполнены.
LLM-эндпоинт `https://foundation-models.api.cloud.ru/v1` работает и изнутри Cloud.ru.

## Шаг 6. Запуск через Docker (поднимет Postgres + поиск по расписанию + Telegram-бот)
```bash
docker compose up -d --build
docker compose logs -f hermes-scheduler   # проверить, что идёт поиск
```
Без Docker (быстрый тест):
```bash
apt install -y python3-pip
pip install -r requirements.txt --break-system-packages
python3 -m hermes kb
python3 -m hermes search "хочу научиться таро"
```

## Шаг 7. После переезда
- Остановить старый агент и **выключить/не продлевать Timeweb-сервер** (экономия).
- Заполнить в `.env` `VK_ACCESS_TOKEN`, `TELEGRAM_BOT_TOKEN`, `DARYA_CHAT_ID` для боевого режима.
- (Опц.) Перевести хранилище на **Managed PostgreSQL Cloud.ru**: `DATABASE_URL=postgresql://...`.

## Проверка «вживую»
Если `python3 -m hermes search ...` выдаёт реальные оценки кандидатов (а не mock) — связка
сервер ↔ Foundation Models работает. Дальше включаем расписание и Telegram.
