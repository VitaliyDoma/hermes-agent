"""Мини-совместимость с pydantic.

Если pydantic установлен (рекомендуется для prod) — используем его. Если нет — лёгкий
fallback BaseModel/Field, достаточный для моделей Hermes (offline-запуск без зависимостей).
"""
from __future__ import annotations

try:  # предпочитаем настоящий pydantic
    from pydantic import BaseModel, Field  # type: ignore
    _PYDANTIC = True
except Exception:  # pragma: no cover - fallback
    _PYDANTIC = False
    import json as _json
    import enum as _enum

    class _FieldInfo:
        __slots__ = ("default", "default_factory")
        def __init__(self, default=None, default_factory=None):
            self.default = default
            self.default_factory = default_factory

    def Field(default=None, *, default_factory=None):  # noqa: N802
        return _FieldInfo(default, default_factory)

    class BaseModel:
        def __init__(self, **data):
            for name, typ in self._annotations().items():
                if name in data:
                    val = data[name]
                else:
                    raw = getattr(type(self), name, None)
                    if isinstance(raw, _FieldInfo):
                        val = raw.default_factory() if raw.default_factory else raw.default
                    else:
                        val = raw
                setattr(self, name, self._coerce(typ, val))

        @classmethod
        def _annotations(cls):
            import typing
            ann = {}
            for klass in reversed(cls.__mro__):
                if klass in (object, BaseModel):
                    continue
                try:
                    ann.update(typing.get_type_hints(klass))
                except Exception:
                    ann.update(getattr(klass, "__annotations__", {}))
            return ann

        @staticmethod
        def _coerce(typ, val):
            try:
                if isinstance(typ, type) and issubclass(typ, _enum.Enum) \
                        and val is not None and not isinstance(val, typ):
                    return typ(val)
            except Exception:
                pass
            return val

        def model_dump(self):
            out = {}
            for name in self._annotations():
                v = getattr(self, name, None)
                if isinstance(v, _enum.Enum):
                    v = v.value
                out[name] = v
            return out

        def model_dump_json(self):
            return _json.dumps(self.model_dump(), ensure_ascii=False, default=str)

        @classmethod
        def model_validate(cls, d):
            return cls(**d)

        @classmethod
        def model_validate_json(cls, s):
            return cls(**_json.loads(s))
