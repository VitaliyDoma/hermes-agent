"""State Storage (M9). Dev → SQLite, Prod → PostgreSQL (через DATABASE_URL).

Выбор бэкенда по CONFIG.database_url:
  sqlite:///hermes.db            → встроенный sqlite3 (dev, без зависимостей)
  postgresql://user:pass@host/db → psycopg2 (prod)
Единый API: init_db, upsert_candidate, get_candidate, save_feedback, list_feedback.
"""
from __future__ import annotations
import os
from typing import Optional
from hermes.models import Candidate, now_iso
from config import CONFIG

# Позволяем переопределить путь sqlite для dev/тестов
_DB_OVERRIDE = os.getenv("HERMES_DB_PATH")


def _is_postgres() -> bool:
    return CONFIG.database_url.startswith("postgres")


# ---------- SQLite backend ----------
def _sqlite_path() -> str:
    if _DB_OVERRIDE:
        return _DB_OVERRIDE
    url = CONFIG.database_url
    return url.replace("sqlite:///", "") if url.startswith("sqlite") else "hermes.db"


def _sqlite_conn():
    import sqlite3
    conn = sqlite3.connect(_sqlite_path())
    conn.row_factory = sqlite3.Row
    return conn


# ---------- Postgres backend ----------
def _pg_conn():  # pragma: no cover - требует БД
    import psycopg2
    import psycopg2.extras
    conn = psycopg2.connect(CONFIG.database_url)
    return conn


def init_db() -> None:
    if _is_postgres():  # pragma: no cover
        with _pg_conn() as c, c.cursor() as cur:
            cur.execute("""CREATE TABLE IF NOT EXISTS candidates(
                candidate_id TEXT PRIMARY KEY, data JSONB, updated_at TIMESTAMPTZ)""")
            cur.execute("""CREATE TABLE IF NOT EXISTS feedback(
                id SERIAL PRIMARY KEY, candidate_id TEXT, label TEXT, reason TEXT,
                created_at TIMESTAMPTZ DEFAULT now())""")
            cur.execute("""CREATE TABLE IF NOT EXISTS rule_sets(
                version TEXT PRIMARY KEY, rules JSONB, created_at TIMESTAMPTZ DEFAULT now())""")
            c.commit()
        return
    with _sqlite_conn() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS candidates(
            candidate_id TEXT PRIMARY KEY, data TEXT, updated_at TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS feedback(
            id INTEGER PRIMARY KEY AUTOINCREMENT, candidate_id TEXT,
            label TEXT, reason TEXT, created_at TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS rule_sets(
            version TEXT PRIMARY KEY, rules TEXT, created_at TEXT)""")


def upsert_candidate(cand: Candidate) -> None:
    payload = cand.model_dump_json()
    if _is_postgres():  # pragma: no cover
        with _pg_conn() as c, c.cursor() as cur:
            cur.execute("""INSERT INTO candidates(candidate_id,data,updated_at)
                VALUES(%s,%s,now()) ON CONFLICT (candidate_id)
                DO UPDATE SET data=EXCLUDED.data, updated_at=now()""",
                (cand.candidate_id, payload))
            c.commit()
        return
    with _sqlite_conn() as c:
        c.execute("REPLACE INTO candidates(candidate_id,data,updated_at) VALUES(?,?,?)",
                  (cand.candidate_id, payload, now_iso()))


def get_candidate(candidate_id: str) -> Optional[Candidate]:
    if _is_postgres():  # pragma: no cover
        with _pg_conn() as c, c.cursor() as cur:
            cur.execute("SELECT data FROM candidates WHERE candidate_id=%s", (candidate_id,))
            row = cur.fetchone()
            return Candidate.model_validate_json(row[0] if isinstance(row[0], str) else __import__("json").dumps(row[0])) if row else None
    with _sqlite_conn() as c:
        row = c.execute("SELECT data FROM candidates WHERE candidate_id=?",
                        (candidate_id,)).fetchone()
        return Candidate.model_validate_json(row["data"]) if row else None


def save_feedback(candidate_id: str, label: str, reason: str = "") -> None:
    if _is_postgres():  # pragma: no cover
        with _pg_conn() as c, c.cursor() as cur:
            cur.execute("INSERT INTO feedback(candidate_id,label,reason) VALUES(%s,%s,%s)",
                        (candidate_id, label, reason))
            c.commit()
        return
    with _sqlite_conn() as c:
        c.execute("INSERT INTO feedback(candidate_id,label,reason,created_at) VALUES(?,?,?,?)",
                  (candidate_id, label, reason, now_iso()))


def list_feedback() -> list[dict]:
    if _is_postgres():  # pragma: no cover
        with _pg_conn() as c, c.cursor() as cur:
            cur.execute("SELECT candidate_id,label,reason FROM feedback ORDER BY id")
            return [{"candidate_id": r[0], "label": r[1], "reason": r[2]} for r in cur.fetchall()]
    with _sqlite_conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM feedback ORDER BY id").fetchall()]
