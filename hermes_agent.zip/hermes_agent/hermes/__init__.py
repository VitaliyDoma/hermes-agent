"""Hermes v3 — DarAngel Lead Agent.

Мультиагентная система поиска тёплых лидов-учеников на курсы по эзотерике Дарьи.
Слои: Conversational (M1,M10), Action (M2-M5), Knowledge (M7), Learning (M6), Safety (M8), Infra (M9).
"""
__version__ = "0.1.0"
