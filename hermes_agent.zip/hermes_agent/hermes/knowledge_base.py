"""Knowledge Base (M7) — канонический source of truth + grounding-хелперы."""
from __future__ import annotations
import json
import os
from typing import Optional

KB_PATH = os.getenv("HERMES_KB_PATH",
                    os.path.join(os.path.dirname(__file__), "..", "data", "knowledge_base.json"))


class KnowledgeBase:
    def __init__(self, path: str = KB_PATH):
        with open(path, encoding="utf-8") as f:
            self.data = json.load(f)

    @property
    def identity(self) -> dict:
        return self.data.get("identity", {})

    @property
    def products(self) -> list[dict]:
        return self.data.get("products", [])

    @property
    def services(self) -> list[dict]:
        return self.data.get("services", [])

    @property
    def ideal_student_profile(self) -> dict:
        return self.data.get("ideal_student_profile", {})

    @property
    def messaging_style(self) -> dict:
        return self.data.get("messaging_style", {})

    def known_product_ids(self) -> set[str]:
        return {p["id"] for p in self.products}

    def get_product(self, product_id: Optional[str]) -> Optional[dict]:
        if not product_id:
            return None
        return next((p for p in self.products if p["id"] == product_id), None)

    def product_names(self) -> set[str]:
        names = set()
        for p in self.products:
            if p.get("name"):
                names.add(p["name"].lower())
        return names

    def compact_context(self) -> str:
        """Сжатый KB-контекст для промптов (экономия токенов)."""
        prods = "; ".join(f"{p['id']}:{p['name']} ({p.get('confidence')})" for p in self.products) or "нет"
        pos = ", ".join(self.ideal_student_profile.get("positive_signals", []))
        neg = ", ".join(self.ideal_student_profile.get("negative_signals", []))
        return (f"identity: {self.identity.get('name')} / {self.identity.get('brand')} / "
                f"{self.identity.get('website')}\nproducts: {prods}\n"
                f"positive_signals: {pos}\nnegative_signals: {neg}\n"
                f"style: {', '.join(self.messaging_style.get('style_rules', []))}")


_KB: Optional[KnowledgeBase] = None


def get_kb() -> KnowledgeBase:
    global _KB
    if _KB is None:
        _KB = KnowledgeBase()
    return _KB
