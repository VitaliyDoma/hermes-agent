"""M8 — Safety Layer. Пост-проверка сообщений и ответов о продуктах."""
from __future__ import annotations
import re
from hermes.models import SafetyVerdict
from hermes.knowledge_base import get_kb

PROMISE_PATTERNS = [r"гарантиру", r"100%", r"обязательно (?:вылеч|разбогат|изменит)",
                    r"исцел", r"привед[её]т к деньгам"]
MINOR_PATTERNS = [r"мне 1[0-7]\b", r"школьник", r"\b[89] класс",
                  r"\b1[0-7]\s*лет(?!\s*назад)", r"несовершеннолет"]
PRICE_PATTERNS = [r"\b\d{3,6}\s?(?:руб|р\.|₽)", r"\bцена\s*[:\-]?\s*\d"]


def check_message(text: str, declared_product_id: str | None = None) -> SafetyVerdict:
    kb = get_kb()
    low = text.lower()

    for p in MINOR_PATTERNS:
        if re.search(p, low):
            return SafetyVerdict(verdict="block", reason="minor")
    for p in PROMISE_PATTERNS:
        if re.search(p, low):
            return SafetyVerdict(verdict="block", reason="promise_of_result")
    for p in PRICE_PATTERNS:
        if re.search(p, low):
            return SafetyVerdict(verdict="block", reason="unconfirmed_price")

    # Упоминание продукта, которого нет в KB → hallucination
    if declared_product_id and declared_product_id not in kb.known_product_ids():
        return SafetyVerdict(verdict="block", reason="hallucinated_product")

    return SafetyVerdict(verdict="pass")


def check_patch_safe(patch_change: str) -> SafetyVerdict:
    """risky_patch_guard: патч не должен ломать инварианты."""
    low = patch_change.lower()
    if "минор" in low or "<18" in low or "несовершеннол" in low:
        return SafetyVerdict(verdict="block", reason="risky_patch_minor")
    if "разрешить эксперт" in low or "продавц" in low and "пропускать" in low:
        return SafetyVerdict(verdict="block", reason="risky_patch_expert")
    return SafetyVerdict(verdict="pass")
