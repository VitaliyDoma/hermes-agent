"""CLI Hermes. Запуск: python -m hermes <команда>."""
from __future__ import annotations
import sys


def cmd_demo(args):
    import run_demo
    run_demo.main()


def cmd_search(args):
    from hermes import pipeline
    from hermes.telegram_bot import render_card
    query = " ".join(args) or "хочу научиться таро"
    res = pipeline.run(query)
    print(f"found={res.found} rerank={res.after_rerank} "
          f"PASS={len(res.passed)} REVIEW={len(res.review)} REJECT={len(res.rejected)}")
    for c in res.passed:
        print("\n" + render_card(c))


def cmd_sweep(args):
    from hermes import scheduler
    scheduler.run_once()


def cmd_bot(args):
    from hermes import telegram_bot
    telegram_bot.main()


def cmd_dashboard(args):
    from hermes.analytics import render_dashboard, compute_kpis
    path = render_dashboard("dashboard.html")
    print("Business KPI:", compute_kpis()["business_kpi"])
    print("Дашборд сохранён:", path)


def cmd_eval(args):
    from hermes.eval import run_eval, print_report
    print_report(run_eval())


def cmd_content(args):
    from hermes.content_engine import generate_content_ideas, render_ideas
    audience = " ".join(args) or "начинающие, интересующиеся таро"
    print(render_ideas(generate_content_ideas(audience)))


def cmd_ask(args):
    from hermes.kb_engine import answer_kb
    q = " ".join(args) or "какие есть курсы?"
    print(answer_kb(q))


def cmd_kb(args):
    from hermes.knowledge_base import get_kb
    kb = get_kb()
    print("Бренд:", kb.identity.get("brand"))
    print("Продукты:")
    for p in kb.products:
        print(f"  - {p['name']} [{p.get('confidence')}] {p.get('source_url','')}")
    print(f"Услуг: {len(kb.services)} | Магазин: {kb.data.get('shop',{}).get('name')}")
    print("Направления:", ", ".join(kb.data.get("expertise", {}).get("core_expertise", [])))


COMMANDS = {"demo": cmd_demo, "search": cmd_search, "sweep": cmd_sweep, "bot": cmd_bot,
            "dashboard": cmd_dashboard, "eval": cmd_eval, "content": cmd_content,
            "ask": cmd_ask, "kb": cmd_kb}


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        print("Hermes CLI. Команды:")
        print("  python -m hermes demo            — офлайн-демо пайплайна")
        print("  python -m hermes search <запрос> — один поиск + отбор")
        print("  python -m hermes sweep           — проход по гипотезам источников")
        print("  python -m hermes content <ауд.>  — идеи вирусного контента под аудиторию")
        print("  python -m hermes ask <вопрос>    — ответ о продуктах из базы знаний")
        print("  python -m hermes dashboard       — собрать KPI-дашборд")
        print("  python -m hermes eval            — калибровка Judge")
        print("  python -m hermes bot             — Telegram-бот")
        print("  python -m hermes kb              — показать Knowledge Base")
        return
    COMMANDS[sys.argv[1]](sys.argv[2:])


if __name__ == "__main__":
    main()
