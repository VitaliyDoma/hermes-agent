"""M3 — Reranker. Cohere при наличии ключа, иначе сигнальный фолбэк-скоринг."""
from __future__ import annotations
from hermes.models import Candidate
from hermes.events import log_event
from hermes.knowledge_base import get_kb
from config import CONFIG


def _fallback_score(c: Candidate) -> float:
    pos = get_kb().ideal_student_profile.get("positive_signals", [])
    neg = get_kb().ideal_student_profile.get("negative_signals", [])
    t = c.raw_text.lower()
    s = 0.4 + 0.12 * sum(1 for p in pos if any(w in t for w in p.lower().split())) \
            - 0.12 * sum(1 for n in neg if any(w in t for w in n.lower().split()))
    return max(0.0, min(1.0, s))


def rerank(candidates: list[Candidate], query: str, run_id: str = "",
           coarse_threshold: float = 0.35) -> list[Candidate]:
    if not candidates:
        return []
    if CONFIG.cohere_api_key:
        scores = _cohere_scores(candidates, query)
    else:
        scores = [_fallback_score(c) for c in candidates]

    for c, s in zip(candidates, scores):
        c.rerank_score = round(float(s), 3)
        c.passed_coarse_filter = c.rerank_score >= coarse_threshold

    ranked = sorted(candidates, key=lambda x: x.rerank_score or 0, reverse=True)
    for i, c in enumerate(ranked):
        c.rerank_rank = i + 1
        log_event("candidate_filtered", run_id=run_id, candidate_id=c.candidate_id,
                  agent_module="rerank", filter_stage="rerank",
                  decision="pass" if c.passed_coarse_filter else "reject",
                  rerank_score=c.rerank_score)
    return [c for c in ranked if c.passed_coarse_filter]


def _cohere_scores(candidates: list[Candidate], query: str) -> list[float]:  # pragma: no cover
    import cohere
    co = cohere.Client(CONFIG.cohere_api_key)
    docs = [c.raw_text for c in candidates]
    res = co.rerank(model="rerank-multilingual-v3.0", query=query, documents=docs)
    scores = [0.0] * len(candidates)
    for r in res.results:
        scores[r.index] = r.relevance_score
    return scores
