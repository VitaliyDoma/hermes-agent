"""Аналитика и KPI Hermes (из событий event log). Расчёт + генерация HTML-дашборда."""
from __future__ import annotations
import html
import json
import os
from collections import Counter, defaultdict
from hermes.events import read_events
from hermes.storage import list_feedback


def compute_kpis(events: list[dict] | None = None) -> dict:
    events = events if events is not None else read_events()
    by_name = Counter(e.get("event_name") for e in events)

    found = by_name.get("candidate_found", 0)
    scored = [e for e in events if e.get("event_name") == "candidate_scored"]
    decisions = Counter(e.get("decision") for e in scored)
    shown = decisions.get("pass", 0)  # PASS = показанные Дарье карточки
    messages = by_name.get("message_generated", 0)
    safety_blocks = by_name.get("safety_guard_triggered", 0)
    runs_completed = by_name.get("run_completed", 0)
    runs_failed = by_name.get("run_failed", 0)

    fb = list_feedback()
    fb_labels = Counter(f["label"] for f in fb)
    labeled = sum(fb_labels.values())

    def ratio(a, b):
        return round(a / b, 3) if b else 0.0

    # модульная нагрузка
    by_module = Counter(e.get("agent_module") for e in events if e.get("agent_module"))

    return {
        "totals": {
            "events": len(events),
            "candidates_found": found,
            "candidates_scored": len(scored),
            "passed_to_darya": shown,
            "messages_generated": messages,
            "safety_blocks": safety_blocks,
            "runs_completed": runs_completed,
            "runs_failed": runs_failed,
        },
        "decisions": dict(decisions),
        "business_kpi": {
            "warm_lead_rate": ratio(decisions.get("pass", 0), len(scored)),
            "reject_rate": ratio(decisions.get("reject", 0), len(scored)),
            "approval_rate_feedback": ratio(fb_labels.get("good_lead", 0), labeled),
            "false_positive_rate": ratio(fb_labels.get("bad_lead", 0), labeled),
            "feedback_coverage": ratio(labeled, shown),
        },
        "agent_kpi": {
            "run_success_rate": ratio(runs_completed, runs_completed + runs_failed),
            "safety_block_rate": ratio(safety_blocks, messages or 1),
        },
        "by_event": dict(by_name),
        "by_module": dict(by_module),
        "feedback": dict(fb_labels),
    }


def render_dashboard(path: str = "dashboard.html") -> str:
    k = compute_kpis()
    data_json = json.dumps(k, ensure_ascii=False)
    t = k["totals"]; b = k["business_kpi"]; a = k["agent_kpi"]

    def card(title, value, sub=""):
        return (f'<div class="card"><div class="t">{html.escape(title)}</div>'
                f'<div class="v">{value}</div><div class="s">{html.escape(sub)}</div></div>')

    cards = "".join([
        card("Найдено кандидатов", t["candidates_found"]),
        card("Оценено (Judge)", t["candidates_scored"]),
        card("Показано Дарье (PASS)", t["passed_to_darya"]),
        card("Сообщений создано", t["messages_generated"]),
        card("Warm-lead rate", b["warm_lead_rate"], "pass / scored"),
        card("False-positive rate", b["false_positive_rate"], "bad / labeled"),
        card("Feedback coverage", b["feedback_coverage"], "labeled / shown"),
        card("Run success rate", a["run_success_rate"]),
        card("Safety-блокировки", t["safety_blocks"]),
    ])

    page = f"""<!doctype html><html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Hermes — KPI Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
:root{{color-scheme:dark}}
body{{font-family:-apple-system,Segoe UI,Roboto,sans-serif;background:#0e1116;color:#e6e6e6;margin:0;padding:24px}}
h1{{font-size:20px;margin:0 0 4px}} .muted{{color:#8a93a2;font-size:13px;margin-bottom:20px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;margin-bottom:24px}}
.card{{background:#171c24;border:1px solid #232a35;border-radius:12px;padding:16px}}
.card .t{{font-size:12px;color:#8a93a2}} .card .v{{font-size:28px;font-weight:700;margin:6px 0}}
.card .s{{font-size:11px;color:#6b7280}}
.row{{display:grid;grid-template-columns:1fr 1fr;gap:16px}}
.panel{{background:#171c24;border:1px solid #232a35;border-radius:12px;padding:16px}}
@media(max-width:760px){{.row{{grid-template-columns:1fr}}}}
</style></head><body>
<h1>Hermes — KPI Dashboard (DarAngel Lead Agent)</h1>
<div class="muted">Источник: event log. Всего событий: {t['events']}.</div>
<div class="grid">{cards}</div>
<div class="row">
  <div class="panel"><canvas id="decisions"></canvas></div>
  <div class="panel"><canvas id="modules"></canvas></div>
</div>
<script>
const K = {data_json};
const dec = K.decisions || {{}};
new Chart(document.getElementById('decisions'), {{type:'doughnut',
  data:{{labels:Object.keys(dec),datasets:[{{data:Object.values(dec),
    backgroundColor:['#34d399','#fbbf24','#f87171','#60a5fa']}}]}},
  options:{{plugins:{{title:{{display:true,text:'Решения Judge',color:'#e6e6e6'}},legend:{{labels:{{color:'#cbd5e1'}}}}}}}}}});
const mod = K.by_module || {{}};
new Chart(document.getElementById('modules'), {{type:'bar',
  data:{{labels:Object.keys(mod),datasets:[{{label:'События по модулям',data:Object.values(mod),
    backgroundColor:'#60a5fa'}}]}},
  options:{{plugins:{{legend:{{labels:{{color:'#cbd5e1'}}}}}},
    scales:{{x:{{ticks:{{color:'#9aa4b2'}}}},y:{{ticks:{{color:'#9aa4b2'}}}}}}}}}});
</script></body></html>"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(page)
    return path
