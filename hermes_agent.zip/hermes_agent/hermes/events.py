"""Аналитика (event schema). Пишет события в JSONL (dev) — поля по спецификации раздела 5."""
from __future__ import annotations
import json
import os
import uuid
from typing import Any, Optional
from hermes.models import now_iso

EVENTS_PATH = os.getenv("HERMES_EVENTS_PATH", "hermes_events.jsonl")


def log_event(event_name: str, *, run_id: str = "", candidate_id: str = "",
              agent_module: str = "", status: str = "success",
              source_type: str = "", confidence: str = "",
              cost_tokens_input: int = 0, cost_tokens_output: int = 0,
              cost_usd_estimate: float = 0.0, **extra: Any) -> dict:
    event = {
        "event_id": str(uuid.uuid4()),
        "event_name": event_name,
        "event_version": "1.0",
        "occurred_at": now_iso(),
        "run_id": run_id,
        "candidate_id": candidate_id,
        "agent_module": agent_module,
        "status": status,
        "source_type": source_type,
        "confidence": confidence,
        "cost_tokens_input": cost_tokens_input,
        "cost_tokens_output": cost_tokens_output,
        "cost_usd_estimate": cost_usd_estimate,
    }
    event.update(extra)
    try:
        with open(EVENTS_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")
    except OSError:
        pass
    return event


def read_events(path: Optional[str] = None) -> list[dict]:
    path = path or EVENTS_PATH
    if not os.path.exists(path):
        return []
    out = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                out.append(json.loads(line))
    return out
