"""M2 — Candidate Search Engine (VK). Реальный VK при наличии токена, иначе sample-данные."""
from __future__ import annotations
import json
import os
import uuid
from typing import Optional
from hermes.models import Candidate
from hermes.events import log_event
from config import CONFIG

SAMPLES = os.path.join(os.path.dirname(__file__), "..", "data", "sample_candidates.json")

# Грубые сигнальные ключи для первичного отбора на этапе поиска
SIGNAL_KEYS = ["научиться", "с чего начать", "новичок", "наставник", "школу",
               "обучение", "курс", "хочу разобраться", "посоветуйте"]


def _extract_signals(text: str) -> list[str]:
    t = text.lower()
    return [k for k in SIGNAL_KEYS if k in t]


def search(query: str, run_id: str = "", limit: int = 20) -> list[Candidate]:
    """Возвращает сырых кандидатов. Офлайн/без токена — из sample_candidates.json."""
    log_event("run_started", run_id=run_id, agent_module="search",
              run_type="search_candidates", user_goal=query)
    cands: list[Candidate] = []

    if CONFIG.vk_access_token:
        cands = _search_vk_api(query, limit)
    else:
        with open(SAMPLES, encoding="utf-8") as f:
            for raw in json.load(f):
                cands.append(Candidate(**raw))

    seen, deduped = set(), []
    for c in cands:
        if not c.raw_signal_tags:
            c.raw_signal_tags = _extract_signals(c.raw_text)
        key = c.platform_user_ref or c.candidate_id
        if key in seen:
            continue
        seen.add(key)
        if not c.found_by_query:
            c.found_by_query = query
        deduped.append(c)
        log_event("candidate_found", run_id=run_id, candidate_id=c.candidate_id,
                  agent_module="search", source_type=c.source_type)

    log_event("run_completed", run_id=run_id, agent_module="search",
              result_count=len(deduped), success_flag=True)
    return deduped[:limit]


def _search_vk_api(query: str, limit: int) -> list[Candidate]:  # pragma: no cover
    import vk_api
    session = vk_api.VkApi(token=CONFIG.vk_access_token)
    api = session.get_api()
    res = api.newsfeed.search(q=query, count=min(limit, 50))
    out = []
    for item in res.get("items", []):
        out.append(Candidate(
            candidate_id=f"vk_{item.get('from_id')}_{item.get('id')}",
            source_id=f"vk_{item.get('owner_id','')}", source_type="vk",
            platform_user_ref=f"vk.com/id{item.get('from_id','')}",
            content_ref=f"vk.com/wall{item.get('owner_id','')}_{item.get('id','')}",
            raw_text=item.get("text", ""), found_by_query=query,
        ))
    return out
