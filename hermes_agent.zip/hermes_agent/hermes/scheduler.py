"""Скедьюлер поиска (этап 4 плана). Управляемый запуск вместо «слепых» 6-часовых циклов.

Режимы:
  python -m hermes.scheduler once        — один проход по всем гипотезам источников
  python -m hermes.scheduler loop 21600  — цикл каждые N секунд (по умолчанию 6 часов)

При наличии TELEGRAM_BOT_TOKEN и DARYA_CHAT_ID найденные PASS-кандидаты отправляются Дарье
карточками с кнопками фидбэка (через telegram_bot.push_cards). Иначе — печатает сводку.
"""
from __future__ import annotations
import sys
import time
from hermes import pipeline, sources
from hermes.events import log_event
from config import CONFIG


def run_once() -> dict:
    qs = sources.queries() or ["хочу научиться таро"]
    summary = {"queries": len(qs), "passed": 0, "review": 0, "rejected": 0, "found": 0}
    all_passed = []
    for q in qs:
        res = pipeline.run(q, generate_messages=True)
        summary["found"] += res.found
        summary["passed"] += len(res.passed)
        summary["review"] += len(res.review)
        summary["rejected"] += len(res.rejected)
        all_passed.extend(res.passed)

    log_event("run_completed", agent_module="scheduler", run_type="scheduled_sweep",
              triggered_by="scheduled", **summary)

    if CONFIG.telegram_bot_token and CONFIG.darya_chat_id and all_passed:
        try:
            from hermes.telegram_bot import push_cards
            push_cards(all_passed)
        except Exception as e:  # pragma: no cover
            print("Не удалось отправить в Telegram:", e)
    else:
        print(f"[scheduler] queries={summary['queries']} found={summary['found']} "
              f"PASS={summary['passed']} REVIEW={summary['review']} REJECT={summary['rejected']}")
        for c in all_passed:
            print(f"  PASS {c.candidate_id}: {c.raw_text[:80]}")
    return summary


def run_loop(interval_sec: int = 21600):
    print(f"[scheduler] loop каждые {interval_sec} сек. Ctrl+C для остановки.")
    while True:
        try:
            run_once()
            time.sleep(interval_sec)
        except Exception as e:  # pragma: no cover
            log_event("run_failed", agent_module="scheduler", error_type=type(e).__name__,
                      error_message_short=str(e)[:200])
            print("[scheduler] ошибка прохода, повтор через 30с:", e)
            time.sleep(30)


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "once"
    if mode == "loop":
        run_loop(int(sys.argv[2]) if len(sys.argv) > 2 else 21600)
    else:
        run_once()
