"""M4 — Lead Judge. Двухступенчатый отбор для экономии:
скрининг дешёвой моделью → эскалация на сильную модель только на спорных кейсах.
"""
from __future__ import annotations
from hermes.models import Candidate, JudgeResult, Decision
from hermes.llm import get_provider, extract_json
from hermes.knowledge_base import get_kb
from hermes.events import log_event
from hermes import prompts
from config import CONFIG


def _build_user(c: Candidate) -> str:
    kb = get_kb()
    return (f"КАНДИДАТ:\nraw_text: {c.raw_text}\nsignals: {c.raw_signal_tags}\n"
            f"source: {c.source_type}\n\nKNOWLEDGE BASE:\n{kb.compact_context()}")


def _judge_once(c: Candidate, model: str, stage: str, run_id: str = "") -> JudgeResult:
    user = _build_user(c)
    raw = get_provider().complete(prompts.JUDGE, user, model=model, json_mode=True)
    data = extract_json(raw)
    try:
        result = JudgeResult(**data)
    except Exception:
        result = JudgeResult(decision=Decision.REVIEW,
                             confidence_explanation="parse_error → ручная проверка")

    # Grounding-страховка: продукт обязан существовать в KB
    if result.recommended_product_id and result.recommended_product_id not in get_kb().known_product_ids():
        result.recommended_product_id = None

    log_event("candidate_scored", run_id=run_id, candidate_id=c.candidate_id,
              agent_module="judge", confidence="high",
              fit_score=result.fit_score, expert_risk_score=result.expert_risk_score,
              decision=result.decision.value, judge_stage=stage, judge_model=model,
              judge_version=result.judge_version)
    return result


def _is_borderline(r: JudgeResult) -> bool:
    if r.decision == Decision.REVIEW:
        return True
    if CONFIG.judge_review_fit_min <= r.fit_score <= 0.7:
        return True
    if 0.2 <= r.expert_risk_score <= 0.5:
        return True
    return False


def judge(c: Candidate, run_id: str = "") -> JudgeResult:
    """Двухступенчатый Judge. Скрининг дешёвой моделью; сильная — только на спорных."""
    if not CONFIG.judge_two_stage:
        return _judge_once(c, CONFIG.judge_strong_model, "single", run_id)

    screen = _judge_once(c, CONFIG.judge_screen_model, "screen", run_id)

    # Офлайн (mock) — обе ступени дают одно и то же, эскалация бессмысленна.
    if CONFIG.offline or not _is_borderline(screen):
        return screen

    # Спорный кейс → сильная модель принимает финальное решение.
    log_event("judge_escalated", run_id=run_id, candidate_id=c.candidate_id,
              agent_module="judge", reason="borderline")
    return _judge_once(c, CONFIG.judge_strong_model, "strong", run_id)


def apply_judge(c: Candidate, result: JudgeResult) -> Candidate:
    c.fit_score = result.fit_score
    c.warmth_score = result.warmth_score
    c.buyer_intent_score = result.buyer_intent_score
    c.expert_risk_score = result.expert_risk_score
    c.decision = result.decision
    c.reason_tags = result.reason_tags
    c.confidence_explanation = result.confidence_explanation
    c.recommended_product_id = result.recommended_product_id
    c.judge_version = result.judge_version
    return c
