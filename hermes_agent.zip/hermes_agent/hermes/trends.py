"""Сбор актуальных трендов под аудиторию/тему для генерации контента.

Приоритет источников:
1) Tavily (глубокий веб-поиск) — если задан TAVILY_API_KEY;
2) VK (недавние посты) — если задан VK_ACCESS_TOKEN;
3) fallback — без выдумок, пометка, что тренды не собраны (идеи на знаниях модели).
"""
from __future__ import annotations
import re
from collections import Counter
from config import CONFIG

_STOP = set("и в во не на я с со что а то по для как из у же ли бы он она они мы вы это так но или".split())


def _keywords(texts: list[str], top: int = 15) -> list[str]:
    words = []
    for t in texts:
        for w in re.findall(r"[a-zа-яё#]{4,}", (t or "").lower()):
            if w not in _STOP:
                words.append(w)
    return [w for w, _ in Counter(words).most_common(top)]


def gather_trends(topic: str, limit: int = 8) -> dict:
    if CONFIG.tavily_api_key:
        try:
            return _tavily_trends(topic, limit)
        except Exception as e:  # pragma: no cover
            pass  # упадём в VK/fallback ниже
    if CONFIG.vk_access_token:
        try:
            return _vk_trends(topic, 50)
        except Exception:  # pragma: no cover
            pass
    return {"source": "fallback", "topic": topic,
            "note": "Источники трендов не заданы (нет TAVILY_API_KEY/VK_ACCESS_TOKEN) — идеи на общих знаниях модели.",
            "sample_count": 0, "top_keywords": [], "samples": []}


def _tavily_trends(topic: str, limit: int) -> dict:  # pragma: no cover - требует ключ/сеть
    import requests
    query = f"актуальные тренды и вирусный контент: {topic} (эзотерика, таро, саморазвитие)"
    r = requests.post("https://api.tavily.com/search", timeout=30, json={
        "api_key": CONFIG.tavily_api_key,
        "query": query,
        "search_depth": "advanced",
        "topic": "general",
        "max_results": min(limit, 10),
        "include_answer": True,
    })
    r.raise_for_status()
    data = r.json()
    results = data.get("results", []) or []
    titles = [x.get("title", "") for x in results]
    contents = [x.get("content", "") for x in results]
    return {
        "source": "tavily",
        "topic": topic,
        "answer": data.get("answer", ""),
        "sample_count": len(results),
        "top_keywords": _keywords(titles + contents, top=15),
        "samples": [f"{t}: {c[:160]}" for t, c in zip(titles, contents)][:6],
        "urls": [x.get("url", "") for x in results][:6],
    }


def _vk_trends(topic: str, limit: int) -> dict:  # pragma: no cover - требует токен
    import vk_api
    api = vk_api.VkApi(token=CONFIG.vk_access_token).get_api()
    res = api.newsfeed.search(q=topic, count=min(limit, 100), extended=0)
    texts = [it.get("text", "") for it in res.get("items", []) if it.get("text")]
    return {"source": "vk", "topic": topic, "sample_count": len(texts),
            "top_keywords": _keywords(texts, 15), "samples": [t[:200] for t in texts[:6]]}


def trends_brief(tr: dict) -> str:
    src = tr.get("source")
    if src == "tavily":
        return (f"Источник: веб-поиск Tavily, найдено материалов: {tr.get('sample_count')}.\n"
                f"Сводка: {tr.get('answer', '')[:400]}\n"
                f"Ключевые темы: {', '.join(tr.get('top_keywords', []))}.\n"
                f"Примеры: " + " | ".join(tr.get('samples', [])[:5]))
    if src == "vk":
        return (f"Источник: VK, постов: {tr.get('sample_count')}.\n"
                f"Частые темы: {', '.join(tr.get('top_keywords', []))}.\n"
                f"Примеры: " + " | ".join(tr.get('samples', [])[:5]))
    return tr.get("note", "Тренды не собраны.")
