"""M10 — Telegram Bot Interface (естественный диалог на русском).

Дарья пишет боту обычным текстом — модуль M1 Router определяет намерение и, при
необходимости, задаёт наводящий вопрос. Поддерживает: поиск лидов, генерацию идей
вирусного контента, ответы о продуктах из базы знаний, фидбэк кнопками под карточками.
Запуск: python -m hermes bot (нужен TELEGRAM_BOT_TOKEN).
"""
from __future__ import annotations
from hermes.models import Candidate
from hermes.storage import save_feedback
from hermes.events import log_event
from config import CONFIG


def render_card(c: Candidate) -> str:
    lines = [
        f"🧭 Кандидат {c.candidate_id}  (источник: {c.source_type})",
        f"Текст: {c.raw_text[:240]}",
        f"fit={c.fit_score}  warmth={c.warmth_score}  intent={c.buyer_intent_score}  expert_risk={c.expert_risk_score}",
        f"Решение: {c.decision.value if c.decision else '-'}  ({', '.join(c.reason_tags)})",
        f"Почему: {c.confidence_explanation}",
    ]
    if c.message_text:
        lines.append(f"\n✉️ Предложенное первое сообщение:\n{c.message_text}")
        lines.append(f"Статус: {c.status} (уйдёт только после вашего подтверждения)")
    return "\n".join(lines)


FEEDBACK_BUTTONS = [("👍 Хороший", "good_lead"), ("👎 Плохой", "bad_lead"),
                    ("🤔 Не уверена", "unsure"), ("♻️ Дубль", "duplicate")]


def record_feedback(candidate_id: str, label: str, reason: str = "") -> None:
    save_feedback(candidate_id, label, reason)
    log_event("candidate_feedback_received", candidate_id=candidate_id,
              agent_module="message_engine", feedback_label=label)


def _kb_markup(candidate_id: str):
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup
    return InlineKeyboardMarkup([[InlineKeyboardButton(t, callback_data=f"{lbl}:{candidate_id}")
                                  for t, lbl in FEEDBACK_BUTTONS]])


def push_cards(candidates):  # pragma: no cover
    if not (CONFIG.telegram_bot_token and CONFIG.darya_chat_id):
        return
    import asyncio
    from telegram import Bot

    async def _send():
        bot = Bot(CONFIG.telegram_bot_token)
        for c in candidates:
            await bot.send_message(chat_id=CONFIG.darya_chat_id, text=render_card(c),
                                   reply_markup=_kb_markup(c.candidate_id))
    asyncio.run(_send())


async def _reply_long(update, text):  # pragma: no cover
    """Telegram лимит ~4096 символов — режем длинные ответы."""
    for i in range(0, len(text), 3500):
        await update.message.reply_text(text[i:i + 3500])


def main():  # pragma: no cover
    if not CONFIG.telegram_bot_token:
        print("TELEGRAM_BOT_TOKEN не задан в .env — Telegram-интерфейс отключён.")
        return
    from telegram import Update
    from telegram.ext import (Application, CommandHandler, CallbackQueryHandler,
                              MessageHandler, ContextTypes, filters)
    from hermes import pipeline, router, content_engine, kb_engine

    app = Application.builder().token(CONFIG.telegram_bot_token).build()

    HELP = ("Здравствуйте! Я Гермес — помощник Дарьи. Пишите мне обычными словами, например:\n"
            "• «найди учеников, которые хотят научиться таро»\n"
            "• «придумай идеи для постов на молодых мам, интересующихся саморазвитием»\n"
            "• «какие у нас есть курсы?»\n"
            "Я сам пойму, что нужно, и при необходимости уточню.")

    async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text(HELP)

    async def on_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        text = (update.message.text or "").strip()
        if not text:
            return
        await update.message.chat.send_action("typing")
        try:
            r = router.route(text)
        except Exception as e:
            await update.message.reply_text(f"Не смог разобрать запрос: {e}")
            return

        if r.get("needs_clarification") and r.get("clarifying_question"):
            await update.message.reply_text(r["clarifying_question"]); return

        intent = r.get("intent", "other")
        params = r.get("params", {}) or {}

        if intent == "generate_content":
            audience = params.get("audience") or text
            await update.message.reply_text("Изучаю тренды и придумываю идеи… (несколько секунд)")
            res = content_engine.generate_content_ideas(audience)
            await _reply_long(update, content_engine.render_ideas(res)); return

        if intent == "ask_kb":
            await _reply_long(update, kb_engine.answer_kb(text)); return

        if intent == "give_feedback":
            await update.message.reply_text(
                "Оценку по кандидату удобнее ставить кнопками 👍/👎 под его карточкой."); return

        # по умолчанию — поиск лидов
        query = params.get("query") or text
        await update.message.reply_text(f"Ищу лидов по запросу: «{query}»…")
        result = pipeline.run(query)
        await update.message.reply_text(
            f"Найдено {result.found}, после отбора: подходящих {len(result.passed)}, "
            f"на проверку {len(result.review)}, отклонено {len(result.rejected)}.")
        for c in result.passed:
            await update.message.reply_text(render_card(c), reply_markup=_kb_markup(c.candidate_id))

    async def on_feedback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        q = update.callback_query
        label, cid = q.data.split(":", 1)
        record_feedback(cid, label)
        await q.answer("Записано, спасибо!")
        await q.edit_message_reply_markup(reply_markup=None)

    app.add_handler(CommandHandler(["start", "help"], start))
    app.add_handler(CallbackQueryHandler(on_feedback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
    print("Hermes Telegram bot запущен (естественный диалог). Напишите боту любое сообщение.")
    app.run_polling()


if __name__ == "__main__":
    main()
