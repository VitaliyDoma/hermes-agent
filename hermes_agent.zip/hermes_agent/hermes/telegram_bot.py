"""M10 — Telegram Bot Interface. Карточки кандидатов Дарье + кнопки фидбэка (human-in-the-loop).

Запуск: python -m hermes.telegram_bot  (нужен TELEGRAM_BOT_TOKEN).
Без токена модуль не стартует — выводит подсказку. Логика карточек вынесена в render_card()
и тестируется офлайн."""
from __future__ import annotations
from hermes.models import Candidate
from hermes.storage import save_feedback
from hermes.events import log_event
from config import CONFIG


def render_card(c: Candidate) -> str:
    """Текст карточки кандидата для Дарьи."""
    lines = [
        f"🧭 Кандидат {c.candidate_id}  (источник: {c.source_type})",
        f"Текст: {c.raw_text[:240]}",
        f"fit={c.fit_score}  warmth={c.warmth_score}  intent={c.buyer_intent_score}  expert_risk={c.expert_risk_score}",
        f"Решение Judge: {c.decision.value if c.decision else '-'}  ({', '.join(c.reason_tags)})",
        f"Почему: {c.confidence_explanation}",
    ]
    if c.message_text:
        lines.append(f"\n✉️ Предложенное первое сообщение:\n{c.message_text}")
        lines.append(f"Статус: {c.status} (уйдёт только после вашего подтверждения)")
    return "\n".join(lines)


FEEDBACK_BUTTONS = [("👍 Хороший", "good_lead"), ("👎 Плохой", "bad_lead"),
                    ("🤔 Не уверена", "unsure"), ("♻️ Дубль", "duplicate")]


def record_feedback(candidate_id: str, label: str, reason: str = "") -> None:
    save_feedback(candidate_id, label, reason)
    log_event("candidate_feedback_received", candidate_id=candidate_id,
              agent_module="message_engine", feedback_label=label)



def push_cards(candidates):  # pragma: no cover
    """Отправляет PASS-кандидатов Дарье карточками с кнопками фидбэка (для scheduler)."""
    if not (CONFIG.telegram_bot_token and CONFIG.darya_chat_id):
        return
    import asyncio
    from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup

    async def _send():
        bot = Bot(CONFIG.telegram_bot_token)
        for c in candidates:
            kb = [InlineKeyboardButton(t, callback_data=f"{lbl}:{c.candidate_id}")
                  for t, lbl in FEEDBACK_BUTTONS]
            await bot.send_message(chat_id=CONFIG.darya_chat_id, text=render_card(c),
                                   reply_markup=InlineKeyboardMarkup([kb]))
    asyncio.run(_send())


def main():  # pragma: no cover
    if not CONFIG.telegram_bot_token:
        print("TELEGRAM_BOT_TOKEN не задан в .env — Telegram-интерфейс отключён.")
        print("Заполните токен и перезапустите: python -m hermes.telegram_bot")
        return
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
    from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
    from hermes import pipeline

    app = Application.builder().token(CONFIG.telegram_bot_token).build()

    async def search_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = " ".join(ctx.args) or "хочу научиться таро"
        result = pipeline.run(query)
        await update.message.reply_text(
            f"Найдено {result.found}, после rerank {result.after_rerank}, "
            f"pass {len(result.passed)} / review {len(result.review)} / reject {len(result.rejected)}")
        for c in result.passed:
            kb = [InlineKeyboardButton(t, callback_data=f"{lbl}:{c.candidate_id}")
                  for t, lbl in FEEDBACK_BUTTONS]
            await update.message.reply_text(
                render_card(c), reply_markup=InlineKeyboardMarkup([kb]))

    async def on_feedback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        q = update.callback_query
        label, cid = q.data.split(":", 1)
        record_feedback(cid, label)
        await q.answer("Записано, спасибо!")
        await q.edit_message_reply_markup(reply_markup=None)

    app.add_handler(CommandHandler("search", search_cmd))
    app.add_handler(CallbackQueryHandler(on_feedback))
    print("Hermes Telegram bot запущен. /search <запрос>")
    app.run_polling()


if __name__ == "__main__":
    main()
