"""Модели данных Hermes. Единый объект candidate обогащается по этапам pipeline."""
from __future__ import annotations
from datetime import datetime, timezone
from enum import Enum
from typing import Optional
from hermes._compat import BaseModel, Field


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class Decision(str, Enum):
    PASS = "pass"
    REVIEW = "review"
    REJECT = "reject"


class FeedbackLabel(str, Enum):
    GOOD = "good_lead"
    BAD = "bad_lead"
    UNSURE = "unsure"
    DUPLICATE = "duplicate"


class Candidate(BaseModel):
    # --- после M2 (Search) ---
    candidate_id: str
    source_id: str
    source_type: str = "vk"            # vk | telegram | forum | site | other
    platform_user_ref: str = ""
    content_ref: str = ""
    raw_text: str = ""
    raw_signal_tags: list[str] = Field(default_factory=list)
    found_by_query: str = ""
    found_at: str = Field(default_factory=now_iso)

    # --- после M3 (Rerank) ---
    rerank_score: Optional[float] = None
    rerank_rank: Optional[int] = None
    passed_coarse_filter: Optional[bool] = None

    # --- после M4 (Judge) ---
    fit_score: Optional[float] = None
    warmth_score: Optional[float] = None
    buyer_intent_score: Optional[float] = None
    expert_risk_score: Optional[float] = None
    decision: Optional[Decision] = None
    reason_tags: list[str] = Field(default_factory=list)
    confidence_explanation: str = ""
    recommended_product_id: Optional[str] = None
    judge_version: str = ""

    # --- после M5 (Message) ---
    message_id: Optional[str] = None
    message_template_id: Optional[str] = None
    channel: Optional[str] = None
    message_text: Optional[str] = None
    passed_safety: Optional[bool] = None
    status: Optional[str] = None        # awaiting_human_approval | approved | rejected | sent


class JudgeResult(BaseModel):
    fit_score: float = 0.0
    warmth_score: float = 0.0
    buyer_intent_score: float = 0.0
    expert_risk_score: float = 0.0
    decision: Decision = Decision.REVIEW
    reason_tags: list[str] = Field(default_factory=list)
    confidence_explanation: str = ""
    recommended_product_id: Optional[str] = None
    judge_version: str = "judge_v1.0"


class GeneratedMessage(BaseModel):
    message_template_id: str = "opener_question_v1"
    text: str = ""
    personalization_note: str = ""
    uses_product_id: Optional[str] = None


class SafetyVerdict(BaseModel):
    verdict: str = "pass"   # pass | block
    reason: str = ""


class RulePatch(BaseModel):
    patch_id: str
    target_rule: str
    change: str
    evidence: str = ""
    expected_effect: str = ""
    risk_note: str = ""
    requires_human_approval: bool = True
