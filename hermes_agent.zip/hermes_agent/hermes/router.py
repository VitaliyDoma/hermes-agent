"""M1 — Conversational Router."""
from __future__ import annotations
from hermes.llm import get_provider, extract_json
from hermes import prompts
from config import CONFIG


def route(user_input: str) -> dict:
    raw = get_provider().complete(prompts.ROUTER, user_input,
                                  model=CONFIG.router_model, json_mode=True)
    data = extract_json(raw)
    data.setdefault("intent", "other")
    data.setdefault("route_to", "clarify")
    return data
