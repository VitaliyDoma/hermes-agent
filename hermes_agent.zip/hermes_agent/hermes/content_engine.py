"""M11 — Генератор вирусных контент-идей.

По запросу Дарьи (целевая аудитория) собирает актуальные тренды (trends.gather_trends),
затем сильной моделью генерирует идеи контента, привязанные к реальным продуктам из KB,
с проверкой Safety. Не выдумывает продукты, не обещает результат.
"""
from __future__ import annotations
import json
from hermes.llm import get_provider, extract_json
from hermes.knowledge_base import get_kb
from hermes.events import log_event
from hermes.safety import check_message
from hermes import prompts, trends
from config import CONFIG


def generate_content_ideas(audience: str, run_id: str = "") -> dict:
    kb = get_kb()
    # 1. Тренды (реальные из VK при наличии токена)
    tr = trends.gather_trends(audience)
    log_event("content_trends_gathered", run_id=run_id, agent_module="content",
              source=tr.get("source"), sample_count=tr.get("sample_count", 0))

    # 2. Генерация идей сильной моделью, grounded на KB
    user = (f"АУДИТОРИЯ: {audience}\n\nТРЕНДЫ:\n{trends.trends_brief(tr)}\n\n"
            f"KNOWLEDGE BASE (реальные продукты Дарьи):\n{kb.compact_context()}")
    raw = get_provider().complete(prompts.CONTENT_IDEAS, user,
                                  model=CONFIG.message_model, json_mode=True)
    data = extract_json(raw)
    ideas = data.get("ideas", []) if isinstance(data, dict) else []

    # 3. Safety + grounding по каждой идее
    known = kb.known_product_ids()
    clean = []
    for idea in ideas:
        text = f"{idea.get('hook','')} {idea.get('angle','')} {idea.get('cta','')}"
        verdict = check_message(text, idea.get("uses_product_id"))
        pid = idea.get("uses_product_id")
        if pid and pid not in known:
            idea["uses_product_id"] = None
        idea["safety"] = verdict.verdict
        if verdict.verdict == "pass":
            clean.append(idea)
        else:
            log_event("safety_guard_triggered", run_id=run_id, agent_module="content",
                      reason=verdict.reason)

    result = {
        "audience": data.get("audience", audience) if isinstance(data, dict) else audience,
        "trend_source": tr.get("source"),
        "trend_summary": data.get("trend_summary", "") if isinstance(data, dict) else "",
        "ideas": clean,
    }
    log_event("content_ideas_generated", run_id=run_id, agent_module="content",
              ideas_count=len(clean), trend_source=tr.get("source"))
    return result


def render_ideas(result: dict) -> str:
    """Человекочитаемый вывод идей для Telegram/CLI."""
    lines = [f"💡 Идеи контента для аудитории: {result.get('audience','')}"]
    src = result.get("trend_source")
    src_label = {"tavily": "реальный веб-поиск (Tavily)", "vk": "VK"}.get(
        src, "общие знания модели — задайте TAVILY_API_KEY или VK_ACCESS_TOKEN")
    lines.append(f"(тренды: {src_label})\n")
    for i, idea in enumerate(result.get("ideas", []), 1):
        lines.append(f"{i}. [{idea.get('format','')}/{idea.get('platform','')}] {idea.get('hook','')}")
        lines.append(f"   Идея: {idea.get('angle','')}")
        if idea.get("cta"):
            lines.append(f"   Призыв: {idea.get('cta')}")
        if idea.get("hashtags"):
            lines.append(f"   Хэштеги: {' '.join(idea.get('hashtags', []))}")
        lines.append(f"   Почему зайдёт: {idea.get('why_viral','')}\n")
    if not result.get("ideas"):
        lines.append("Идеи не сгенерированы (проверьте LLM-ключ/ответ модели).")
    return "\n".join(lines)
