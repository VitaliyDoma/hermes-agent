"""Гипотезы источников лидов (M2). Загружает data/sources.json."""
from __future__ import annotations
import json
import os

SOURCES_PATH = os.getenv("HERMES_SOURCES_PATH",
                         os.path.join(os.path.dirname(__file__), "..", "data", "sources.json"))


def load_sources() -> dict:
    with open(SOURCES_PATH, encoding="utf-8") as f:
        return json.load(f)


def queries() -> list[str]:
    return load_sources().get("queries", [])
