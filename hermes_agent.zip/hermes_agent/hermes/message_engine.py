"""M5 — Message Generator. Первое сообщение в стиле Дарьи (grounded, через Safety)."""
from __future__ import annotations
import uuid
from hermes.models import Candidate, GeneratedMessage
from hermes.llm import get_provider, extract_json
from hermes.knowledge_base import get_kb
from hermes.events import log_event
from hermes.safety import check_message
from hermes import prompts
from config import CONFIG


def generate(c: Candidate, run_id: str = "") -> Candidate:
    kb = get_kb()
    product = kb.get_product(c.recommended_product_id)
    user = (f"КАНДИДАТ raw_text: {c.raw_text}\nreason_tags: {c.reason_tags}\n"
            f"recommended_product: {product}\nstyle: {kb.messaging_style}")
    raw = get_provider().complete(prompts.MESSAGE, user, model=CONFIG.message_model, json_mode=True)
    data = extract_json(raw)
    try:
        gen = GeneratedMessage(**data)
    except Exception:
        gen = GeneratedMessage(text=kb.messaging_style.get("example_opener", ""))

    verdict = check_message(gen.text, gen.uses_product_id)
    c.message_id = f"m_{uuid.uuid4().hex[:8]}"
    c.message_template_id = gen.message_template_id
    c.channel = c.source_type
    c.message_text = gen.text
    c.passed_safety = verdict.verdict == "pass"
    c.status = "awaiting_human_approval" if c.passed_safety else "blocked_by_safety"

    log_event("message_generated", run_id=run_id, candidate_id=c.candidate_id,
              agent_module="message_engine", status="success" if c.passed_safety else "warning",
              passed_safety=c.passed_safety, safety_reason=verdict.reason)
    if not c.passed_safety:
        log_event("safety_guard_triggered", run_id=run_id, candidate_id=c.candidate_id,
                  agent_module="message_engine", reason=verdict.reason)
    return c
