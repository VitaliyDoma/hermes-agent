"""Абстракция LLM-провайдера (M-Model Stack).

Поддерживает openai / anthropic; при отсутствии ключей или LLM_PROVIDER=mock
использует детерминированный MockProvider, чтобы pipeline работал офлайн и в тестах.
"""
from __future__ import annotations
import json
import re
from typing import Optional

from config import CONFIG


class BaseProvider:
    def complete(self, system: str, user: str, model: Optional[str] = None,
                 json_mode: bool = False) -> str:
        raise NotImplementedError


class OpenAIProvider(BaseProvider):
    """OpenAI-совместимый клиент. Подходит и для Cloud.ru Foundation Models (base_url)."""
    def __init__(self, api_key: str, base_url: str | None = None):
        from openai import OpenAI
        self.client = OpenAI(api_key=api_key, base_url=base_url) if base_url else OpenAI(api_key=api_key)

    def complete(self, system, user, model=None, json_mode=False):
        kwargs = {}
        if json_mode:
            kwargs["response_format"] = {"type": "json_object"}
        resp = self.client.chat.completions.create(
            model=model or CONFIG.judge_model,
            messages=[{"role": "system", "content": system},
                      {"role": "user", "content": user}],
            temperature=0.3, **kwargs,
        )
        return resp.choices[0].message.content or ""


class AnthropicProvider(BaseProvider):
    def __init__(self, api_key: str):
        import anthropic
        self.client = anthropic.Anthropic(api_key=api_key)

    def complete(self, system, user, model=None, json_mode=False):
        msg = self.client.messages.create(
            model=model or "claude-sonnet-4-6",
            max_tokens=1024, system=system,
            messages=[{"role": "user", "content": user}],
        )
        return "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")


class MockProvider(BaseProvider):
    """Детерминированные ответы по эвристикам — имитируют Judge/Router/Message офлайн."""

    POS = ["хочу научиться", "научиться", "освоить", "обучиться", "с чего начать",
           "ищу наставника", "наставник", "ищу школу", "научите", "курс", "обучение",
           "хочу разобраться", "новичок", "посоветуйте школу", "хочу обучиться"]
    NEG = ["провожу консультации", "набор в мою группу", "мои услуги", "запись ко мне",
           "опыт работы", "сертифицированный", "продаю", "магазин", "мой канал", "реклама"]
    MINOR = ["мне 15", "мне 16", "мне 17", "школьник", "8 класс", "9 класс"]

    def complete(self, system, user, model=None, json_mode=False):
        text = user.lower()

        if "маршрутизатор" in system.lower() or "router" in system.lower():
            t = user.lower()
            if any(k in t for k in ["контент", "идеи", "пост", "вирус", "reels", "рилс", "сторис"]):
                return json.dumps({"intent": "generate_content", "route_to": "content",
                                   "params": {"audience": user}, "needs_clarification": False}, ensure_ascii=False)
            if any(k in t for k in ["курс", "цен", "услуг", "продукт", "что есть", "расскажи о"]):
                return json.dumps({"intent": "ask_kb", "route_to": "M7", "params": {}, "needs_clarification": False}, ensure_ascii=False)
            if any(k in t for k in ["хорош", "плох", "не то", "подходит", "лид"]):
                return json.dumps({"intent": "give_feedback", "route_to": "M6", "params": {}, "needs_clarification": False}, ensure_ascii=False)
            return json.dumps({"intent": "search_leads", "route_to": "M2",
                               "params": {"query": user}, "needs_clarification": False}, ensure_ascii=False)

        if "движок ответов по knowledge base" in system.lower():
            return ("У Дарьи (DarAngel) есть обучение по Таро (курс «от новичка до мастера»), "
                    "марафон «Трансформация» и курс «Магия Рода», а также консультации-расклады. "
                    "Актуальные цены и даты старта — на darangel.ru. (демо-ответ)")
        if "судья" in system.lower() or "lead judge" in system.lower():
            cand_only = text.split("knowledge base")[0]
            return json.dumps(self._judge(cand_only), ensure_ascii=False)

        if "продюсер вирусного контента" in system.lower() or "content" in system.lower() and "идеи" in system.lower():
            return json.dumps({
                "audience": "указанная аудитория",
                "trend_summary": "учтены частые запросы новичков об обучении таро и саморазвитии (mock).",
                "ideas": [
                    {"hook": "3 ошибки новичка в Таро, из-за которых расклады врут",
                     "format": "reels", "platform": "VK", "angle": "Короткое видео с разбором типичных ошибок и приглашением учиться системно.",
                     "cta": "Подробнее о курсе для начинающих — на darangel.ru",
                     "uses_product_id": "p_taro_course", "hashtags": ["#таро", "#обучениетаро"],
                     "why_viral": "Формат «ошибки новичка» хорошо заходит и цепляет начинающих (mock-тренд)."},
                    {"hook": "Что карта дня говорит о тебе на этой неделе",
                     "format": "сторис", "platform": "Telegram", "angle": "Серия сторис с картой дня и мини-трактовкой.",
                     "cta": "Хочешь научиться читать сама? Напиши «хочу учиться».",
                     "uses_product_id": "p_taro_course", "hashtags": ["#картадня"],
                     "why_viral": "Вовлекающий ежедневный формат (mock-тренд)."}
                ]
            }, ensure_ascii=False)
        if "сообщени" in system.lower() or "message generator" in system.lower():
            return json.dumps({
                "message_template_id": "opener_question_v1",
                "text": ("Здравствуйте! Увидел(а) ваш вопрос про обучение — у Дарьи (DarAngel) "
                         "есть форматы как раз для начинающих. Если интересно, расскажу подробнее, "
                         "а актуальные детали всегда есть на darangel.ru."),
                "personalization_note": "Ответ на явный интерес к обучению",
                "uses_product_id": None,
            }, ensure_ascii=False)

        return "{}"

    def _judge(self, text: str) -> dict:
        pos = sum(1 for k in self.POS if k in text)
        neg = sum(1 for k in self.NEG if k in text)
        minor = any(k in text for k in self.MINOR)

        fit = min(1.0, 0.2 + 0.22 * pos - 0.18 * neg)
        fit = max(0.0, fit)
        warmth = min(1.0, 0.15 + 0.25 * pos)
        intent = min(1.0, 0.1 + 0.2 * pos)
        expert_risk = min(1.0, 0.05 + 0.3 * neg)

        tags = []
        if pos: tags.append("learning_intent")
        if neg: tags.append("expert_or_seller_signal")
        if minor:
            return {"fit_score": 0.0, "warmth_score": 0.0, "buyer_intent_score": 0.0,
                    "expert_risk_score": 0.0, "decision": "reject",
                    "reason_tags": ["minor"], "confidence_explanation": "Признаки несовершеннолетнего",
                    "recommended_product_id": None, "judge_version": "judge_v1.0_mock"}

        if fit >= CONFIG.judge_pass_fit and expert_risk <= CONFIG.judge_pass_expert_risk_max:
            decision = "pass"
        elif fit < CONFIG.judge_review_fit_min or expert_risk > 0.5:
            decision = "reject"
        else:
            decision = "review"

        return {"fit_score": round(fit, 2), "warmth_score": round(warmth, 2),
                "buyer_intent_score": round(intent, 2), "expert_risk_score": round(expert_risk, 2),
                "decision": decision, "reason_tags": tags or ["weak_signal"],
                "confidence_explanation": f"pos={pos}, neg={neg} (mock-эвристика)",
                "recommended_product_id": "p_taro_basic" if "таро" in text else None,
                "judge_version": "judge_v1.0_mock"}


_PROVIDER: Optional[BaseProvider] = None


def get_provider() -> BaseProvider:
    global _PROVIDER
    if _PROVIDER is not None:
        return _PROVIDER
    if CONFIG.offline:
        _PROVIDER = MockProvider()
    elif CONFIG.llm_provider == "cloudru":
        _PROVIDER = OpenAIProvider(CONFIG.llm_api_key, base_url=CONFIG.llm_base_url)
    elif CONFIG.llm_provider == "openai":
        _PROVIDER = OpenAIProvider(CONFIG.llm_api_key, base_url=CONFIG.llm_base_url or None)
    elif CONFIG.llm_provider == "anthropic":
        _PROVIDER = AnthropicProvider(CONFIG.anthropic_api_key)
    else:
        _PROVIDER = MockProvider()
    return _PROVIDER


def extract_json(s: str) -> dict:
    """Безопасно достаёт JSON из ответа LLM (в т.ч. если он обёрнут текстом)."""
    s = s.strip()
    try:
        return json.loads(s)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", s, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                pass
    return {}
