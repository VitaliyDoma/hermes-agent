"""M6 — Feedback & Learning Loop. Фидбэк → предложение патча → safety → подтверждение человеком."""
from __future__ import annotations
import uuid
from collections import Counter
from hermes.models import RulePatch
from hermes.storage import list_feedback
from hermes.events import log_event
from hermes.safety import check_patch_safe


def analyze_feedback() -> list[RulePatch]:
    """Простой baseline-анализ: если много bad_lead с экспертами — предложить ужесточить порог."""
    fb = list_feedback()
    patches: list[RulePatch] = []
    labels = Counter(f["label"] for f in fb)
    bad = labels.get("bad_lead", 0)
    total = sum(labels.values()) or 1

    if bad / total >= 0.3 and bad >= 3:
        patch = RulePatch(
            patch_id=f"patch_{uuid.uuid4().hex[:6]}",
            target_rule="judge.expert_risk_threshold",
            change="Понизить порог expert_risk для pass с 0.3 до 0.25 (больше отсекать экспертов)",
            evidence=f"{bad} bad_lead из {total} размеченных",
            expected_effect="Снижение false-positive rate",
            risk_note="Возможен рост review (пограничные случаи)",
        )
        verdict = check_patch_safe(patch.change)
        if verdict.verdict == "pass":
            patches.append(patch)
            log_event("patch_proposed", agent_module="learning", patch_id=patch.patch_id)
        else:
            log_event("safety_guard_triggered", agent_module="learning", reason=verdict.reason)
    return patches


def apply_patch(patch: RulePatch, approved: bool) -> None:
    """Патч применяется ТОЛЬКО при approved=True (human-in-the-loop)."""
    if approved:
        log_event("patch_approved", agent_module="learning", patch_id=patch.patch_id)
    else:
        log_event("patch_rejected", agent_module="learning", patch_id=patch.patch_id)
