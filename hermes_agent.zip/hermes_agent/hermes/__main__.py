from hermes.cli import main
main()
