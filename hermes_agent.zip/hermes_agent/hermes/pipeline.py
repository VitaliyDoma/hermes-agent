"""Оркестратор: search → rerank → judge → (message для pass) → state.

Реализует MVP-связку M1→M2→M3→M4 (+M5/M8). Сообщения только для decision=pass,
и только в статусе awaiting_human_approval (человек в контуре)."""
from __future__ import annotations
import uuid
from dataclasses import dataclass, field
from hermes.models import Candidate, Decision
from hermes import search_vk, reranker, judge as judge_mod, message_engine
from hermes.storage import init_db, upsert_candidate
from hermes.events import log_event


@dataclass
class PipelineResult:
    run_id: str
    query: str
    found: int = 0
    after_rerank: int = 0
    passed: list[Candidate] = field(default_factory=list)
    review: list[Candidate] = field(default_factory=list)
    rejected: list[Candidate] = field(default_factory=list)


def run(query: str, limit: int = 20, generate_messages: bool = True) -> PipelineResult:
    run_id = f"run_{uuid.uuid4().hex[:8]}"
    init_db()
    res = PipelineResult(run_id=run_id, query=query)

    candidates = search_vk.search(query, run_id=run_id, limit=limit)
    res.found = len(candidates)

    candidates = reranker.rerank(candidates, query, run_id=run_id)
    res.after_rerank = len(candidates)

    for c in candidates:
        verdict = judge_mod.judge(c, run_id=run_id)
        judge_mod.apply_judge(c, verdict)

        if c.decision == Decision.PASS:
            if generate_messages:
                message_engine.generate(c, run_id=run_id)
            res.passed.append(c)
        elif c.decision == Decision.REVIEW:
            res.review.append(c)
        else:
            res.rejected.append(c)
        upsert_candidate(c)

    log_event("run_completed", run_id=run_id, agent_module="pipeline",
              result_count=res.found, passed=len(res.passed),
              review=len(res.review), rejected=len(res.rejected), success_flag=True)
    return res
