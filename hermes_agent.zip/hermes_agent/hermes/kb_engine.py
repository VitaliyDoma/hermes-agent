"""M7-ответы: grounded-ответ на вопрос о продуктах/услугах Дарьи (только из KB)."""
from __future__ import annotations
from hermes.llm import get_provider
from hermes.knowledge_base import get_kb
from hermes import prompts
from config import CONFIG


def answer_kb(question: str) -> str:
    kb = get_kb()
    user = f"ВОПРОС: {question}\n\nKNOWLEDGE BASE:\n{kb.compact_context()}"
    return get_provider().complete(prompts.KB_ENGINE, user, model=CONFIG.kb_model).strip()
