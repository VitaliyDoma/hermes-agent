"""Eval-harness для Judge (этап 1 плана: согласие с разметкой Дарьи ≥ 80%).

Прогоняет размеченный набор data/eval_set.json через Judge и считает:
- agreement (доля совпадений pass/reject; review-кейсы засчитываются как «мягко верно»);
- precision/recall по классу pass (целевые ученики);
- confusion-таблицу.
"""
from __future__ import annotations
import json
import os
from collections import Counter
from hermes.models import Candidate
from hermes import judge as judge_mod

EVAL_PATH = os.getenv("HERMES_EVAL_PATH",
                      os.path.join(os.path.dirname(__file__), "..", "data", "eval_set.json"))


def run_eval(path: str = EVAL_PATH) -> dict:
    with open(path, encoding="utf-8") as f:
        items = json.load(f)

    confusion = Counter()
    agree = 0
    tp = fp = fn = 0
    rows = []
    for i, it in enumerate(items):
        c = Candidate(candidate_id=f"eval_{i}", source_id="eval", raw_text=it["text"])
        pred = judge_mod.judge(c).decision.value
        gold = it["gold"]
        confusion[(gold, pred)] += 1

        # agreement: точное совпадение, либо любой из {gold,pred} == review (пограничные)
        if pred == gold or "review" in (pred, gold):
            agree += 1
        # precision/recall по pass
        if gold == "pass" and pred == "pass":
            tp += 1
        elif gold != "pass" and pred == "pass":
            fp += 1
        elif gold == "pass" and pred != "pass":
            fn += 1
        rows.append({"text": it["text"][:60], "gold": gold, "pred": pred})

    n = len(items)
    precision = round(tp / (tp + fp), 3) if (tp + fp) else 0.0
    recall = round(tp / (tp + fn), 3) if (tp + fn) else 0.0
    return {
        "n": n,
        "agreement": round(agree / n, 3) if n else 0.0,
        "pass_precision": precision,
        "pass_recall": recall,
        "confusion": {f"{g}->{p}": v for (g, p), v in sorted(confusion.items())},
        "rows": rows,
    }


def print_report(res: dict) -> None:
    print(f"Eval set: {res['n']} примеров")
    print(f"Agreement: {res['agreement']:.0%}  (цель ≥ 80%)")
    print(f"PASS precision: {res['pass_precision']:.0%} | PASS recall: {res['pass_recall']:.0%}")
    print("Confusion (gold->pred):")
    for k, v in res["confusion"].items():
        print(f"  {k}: {v}")
    mism = [r for r in res["rows"] if r["gold"] != r["pred"] and "review" not in (r["gold"], r["pred"])]
    if mism:
        print("Жёсткие расхождения:")
        for r in mism:
            print(f"  gold={r['gold']} pred={r['pred']} :: {r['text']}")


if __name__ == "__main__":
    print_report(run_eval())
