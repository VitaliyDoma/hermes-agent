# Changelog

## 0.1.0 — 2026-06-15
Первый рабочий каркас агента Hermes v3 (DarAngel Lead Agent).

### Архитектура
- 5 слоёв (Conversational, Action, Knowledge, Learning, Safety) + инфраструктура, модули M1–M10.
- Пайплайн отбора: search → rerank → judge → message → safety, человек в контуре.

### Модули
- M1 Router, M2 VK Search (+гипотезы источников), M3 Reranker (Cohere), M4 Lead Judge
  (scoring rubric под эзотерику), M5 Message Generator, M6 Learning Loop, M7 Knowledge Base,
  M8 Safety Layer, M9 State Storage (SQLite/PostgreSQL), M10 Telegram Bot.

### Knowledge Base
- Реальные данные с darangel.ru: 3 курса/марафона, 12 услуг, магазин, 7 направлений.
- Парсер `tools_kb_parser.py` для обновления базы.

### Инфраструктура и качество
- LLM-абстракция (OpenAI/Anthropic/Mock), офлайн-режим.
- Скедьюлер поиска, CLI (`python -m hermes ...`).
- KPI-дашборд (`analytics.py`), eval-harness калибровки Judge (100% agreement на стартовом наборе).
- 16 тестов, GitHub Actions CI, Docker + docker-compose, инструкции деплоя на Timeweb.

## 0.2.0 — 2026-06-17
- M1 Router подключён к Telegram: естественный диалог на русском с наводящими вопросами (без команд).
- M11 «Вирусный контент»: генерация идей под заданную аудиторию на основе трендов (VK) + grounding на KB + Safety.
- Движок ответов о продуктах (M7) для вопросов Дарьи; CLI `content` и `ask`.
- Стабильность: healthcheck БД в docker-compose, ретрай скедьюлера; команда обновления с сохранением .env.
- Тесты: 24 (добавлены router-интенты, контент-идеи, KB-ответы).

- M11 тренды: подключён веб-поиск Tavily (TAVILY_API_KEY) как основной источник трендов для контент-идей (приоритет: Tavily > VK > fallback).

- Telegram через прокси (TELEGRAM_PROXY) + увеличенные таймауты — обход блокировки api.telegram.org на сервере.
