# Changelog

## 0.1.0 — 2026-06-15
Первый рабочий каркас агента Hermes v3 (DarAngel Lead Agent).

### Архитектура
- 5 слоёв (Conversational, Action, Knowledge, Learning, Safety) + инфраструктура, модули M1–M10.
- Пайплайн отбора: search → rerank → judge → message → safety, человек в контуре.

### Модули
- M1 Router, M2 VK Search (+гипотезы источников), M3 Reranker (Cohere), M4 Lead Judge
  (scoring rubric под эзотерику), M5 Message Generator, M6 Learning Loop, M7 Knowledge Base,
  M8 Safety Layer, M9 State Storage (SQLite/PostgreSQL), M10 Telegram Bot.

### Knowledge Base
- Реальные данные с darangel.ru: 3 курса/марафона, 12 услуг, магазин, 7 направлений.
- Парсер `tools_kb_parser.py` для обновления базы.

### Инфраструктура и качество
- LLM-абстракция (OpenAI/Anthropic/Mock), офлайн-режим.
- Скедьюлер поиска, CLI (`python -m hermes ...`).
- KPI-дашборд (`analytics.py`), eval-harness калибровки Judge (100% agreement на стартовом наборе).
- 16 тестов, GitHub Actions CI, Docker + docker-compose, инструкции деплоя на Timeweb.
