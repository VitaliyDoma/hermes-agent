"""Демо end-to-end (офлайн на MockProvider). Прогон pipeline + карточки кандидатов."""
from hermes import pipeline
from hermes.telegram_bot import render_card
from hermes.events import read_events


def main():
    print("=" * 70)
    print("HERMES v3 — DEMO (offline / MockProvider)")
    print("=" * 70)
    result = pipeline.run("хочу научиться таро, ищу школу по астрологии", generate_messages=True)

    print(f"\nRun: {result.run_id}  Запрос: {result.query}")
    print(f"Найдено: {result.found} | после rerank: {result.after_rerank}")
    print(f"PASS: {len(result.passed)}  REVIEW: {len(result.review)}  REJECT: {len(result.rejected)}\n")

    for bucket, title in [(result.passed, "✅ PASS (готовы к контакту, ждут подтверждения)"),
                          (result.review, "🟨 REVIEW (на ручную проверку)"),
                          (result.rejected, "⛔ REJECT (нецелевые)")]:
        if bucket:
            print(f"\n--- {title} ---")
            for c in bucket:
                print("\n" + render_card(c))

    print("\n" + "=" * 70)
    print(f"Событий аналитики записано: {len(read_events())} (см. hermes_events.jsonl)")


if __name__ == "__main__":
    main()
