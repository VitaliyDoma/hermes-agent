"""Конвертер VLESS-ссылки → xray-конфиг с локальным SOCKS5 (для обхода блокировки Telegram).

Запуск НА СЕРВЕРЕ (ссылка остаётся только там):
    python3 tools_vless_proxy.py
Скрипт спросит твою ссылку vless://..., создаст рядом файл xray-config.json
с SOCKS5-входом на порту 1080 и VLESS-выходом на твой сервер Aeza.
Поддерживает Reality и TLS, транспорт tcp/ws/grpc.
"""
from __future__ import annotations
import json
import sys
from urllib.parse import urlparse, parse_qs, unquote


def parse_vless(link: str) -> dict:
    link = link.strip()
    if not link.startswith("vless://"):
        raise ValueError("Это не vless:// ссылка")
    u = urlparse(link)
    uuid = unquote(u.username or "")
    host = u.hostname
    port = int(u.port or 443)
    q = {k: v[0] for k, v in parse_qs(u.query).items()}
    net = q.get("type", "tcp")
    security = q.get("security", "none")

    stream = {"network": net, "security": security}
    if security == "reality":
        stream["realitySettings"] = {
            "serverName": q.get("sni", ""),
            "fingerprint": q.get("fp", "chrome"),
            "publicKey": q.get("pbk", ""),
            "shortId": q.get("sid", ""),
            "spiderX": q.get("spx", "/"),
        }
    elif security == "tls":
        stream["tlsSettings"] = {
            "serverName": q.get("sni", q.get("host", host)),
            "fingerprint": q.get("fp", "chrome"),
            "allowInsecure": q.get("allowInsecure", "0") == "1",
        }
    if net == "ws":
        stream["wsSettings"] = {"path": unquote(q.get("path", "/")),
                                "headers": {"Host": q.get("host", "")}}
    elif net == "grpc":
        stream["grpcSettings"] = {"serviceName": unquote(q.get("serviceName", ""))}
    elif net == "tcp" and q.get("headerType") == "http":
        stream["tcpSettings"] = {"header": {"type": "http"}}

    user = {"id": uuid, "encryption": q.get("encryption", "none")}
    if q.get("flow"):
        user["flow"] = q["flow"]

    return {
        "log": {"loglevel": "warning"},
        "inbounds": [{
            "tag": "socks-in", "listen": "0.0.0.0", "port": 1080, "protocol": "socks",
            "settings": {"udp": True, "auth": "noauth"},
        }],
        "outbounds": [{
            "protocol": "vless",
            "settings": {"vnext": [{"address": host, "port": port, "users": [user]}]},
            "streamSettings": stream,
        }],
    }


def main():
    print("Вставь свою ссылку vless://... и нажми Enter:")
    link = sys.stdin.readline()
    cfg = parse_vless(link)
    with open("xray-config.json", "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    out = cfg["outbounds"][0]["settings"]["vnext"][0]
    print(f"\n✓ xray-config.json создан. Сервер: {out['address']}:{out['port']}, "
          f"транспорт: {cfg['outbounds'][0]['streamSettings']['network']}, "
          f"security: {cfg['outbounds'][0]['streamSettings']['security']}")
    print("SOCKS5 будет доступен внутри Docker как socks5h://xray:1080")


if __name__ == "__main__":
    main()
