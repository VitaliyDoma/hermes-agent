"""Изоляция тестов: временные БД/события, mock-провайдер."""
import os
import pytest


@pytest.fixture(autouse=True)
def _isolate(tmp_path, monkeypatch):
    monkeypatch.setenv("HERMES_DB_PATH", str(tmp_path / "t.db"))
    monkeypatch.setenv("HERMES_EVENTS_PATH", str(tmp_path / "t.jsonl"))
    monkeypatch.setenv("LLM_PROVIDER", "mock")
    yield
