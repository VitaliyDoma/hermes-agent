"""Расширенные тесты модулей Hermes (офлайн, MockProvider)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from hermes.models import Candidate, Decision
from hermes import router, reranker, judge as judge_mod, message_engine
from hermes.knowledge_base import get_kb
from hermes.safety import check_message, check_patch_safe


def _c(text, cid="c"):
    return Candidate(candidate_id=cid, source_id="s", raw_text=text)


# --- Router ---
def test_router_returns_route():
    r = router.route("найди мне учеников по таро")
    assert "route_to" in r and "intent" in r


# --- Reranker ---
def test_reranker_filters_and_ranks():
    cands = [_c("хочу научиться таро с нуля", "a"),
             _c("просто погода сегодня", "b")]
    out = reranker.rerank(cands, "обучение таро")
    assert all(c.rerank_rank is not None for c in out)
    # релевантный должен пройти грубый фильтр
    ids = [c.candidate_id for c in out]
    assert "a" in ids


# --- Judge grounding ---
def test_judge_recommends_only_known_products():
    c = _c("хочу научиться таро, я новичок, с чего начать", "p")
    r = judge_mod.judge(c)
    if r.recommended_product_id:
        assert r.recommended_product_id in get_kb().known_product_ids()


def test_judge_seller_high_expert_risk():
    c = _c("Продаю карты таро и свечи, мой магазин, обращайтесь")
    r = judge_mod.judge(c)
    assert r.expert_risk_score > 0.3


# --- Message + safety ---
def test_message_generated_passes_safety():
    c = _c("хочу научиться таро, посоветуйте курс", "m")
    judge_mod.apply_judge(c, judge_mod.judge(c))
    message_engine.generate(c)
    assert c.message_text
    assert c.passed_safety is True
    assert c.status == "awaiting_human_approval"


def test_safety_blocks_hallucinated_product():
    v = check_message("Приходите на наш курс по рунам за деньги", declared_product_id="p_not_in_kb")
    assert v.verdict == "block"


def test_safety_blocks_minor_mention():
    assert check_message("Здравствуйте, вам ведь 16 лет?").verdict == "block"


def test_risky_patch_guard():
    assert check_patch_safe("разрешить пропускать продавцов как лидов").verdict == "block"
    assert check_patch_safe("понизить порог expert_risk до 0.25").verdict == "pass"


# --- Storage ---
def test_storage_roundtrip():
    from hermes import storage
    storage.init_db()
    storage.upsert_candidate(_c("hi", "s1"))
    storage.save_feedback("s1", "good_lead", "ok")
    assert storage.get_candidate("s1").candidate_id == "s1"
    assert storage.list_feedback()[0]["label"] == "good_lead"


# --- Analytics ---
def test_analytics_kpis_after_run():
    from hermes import pipeline
    from hermes.analytics import compute_kpis
    pipeline.run("хочу научиться таро")
    k = compute_kpis()
    assert k["totals"]["candidates_scored"] >= 1
    assert "warm_lead_rate" in k["business_kpi"]


# --- KB integrity ---
def test_kb_has_real_products():
    kb = get_kb()
    assert len(kb.products) >= 3
    assert kb.identity["name"] == "Дарья Домаева"
    assert any("Таро" in p["name"] for p in kb.products)


def test_eval_harness_runs():
    from hermes.eval import run_eval
    res = run_eval()
    assert res["n"] >= 10
    assert 0.0 <= res["agreement"] <= 1.0
    # на стартовом наборе целевые ученики не должны массово теряться
    assert res["pass_precision"] >= 0.7


def test_judge_two_stage_borderline_logic():
    from hermes.judge import _is_borderline
    from hermes.models import JudgeResult, Decision
    # review всегда спорный
    assert _is_borderline(JudgeResult(decision=Decision.REVIEW))
    # явный ученик — не спорный
    assert not _is_borderline(JudgeResult(fit_score=0.9, expert_risk_score=0.02, decision=Decision.PASS))
    # явный эксперт — не спорный
    assert not _is_borderline(JudgeResult(fit_score=0.1, expert_risk_score=0.9, decision=Decision.REJECT))
    # пограничный fit
    assert _is_borderline(JudgeResult(fit_score=0.55, expert_risk_score=0.1, decision=Decision.PASS))


def test_judge_runs_with_two_stage_flag():
    from hermes import judge as jm
    from hermes.models import Candidate
    c = Candidate(candidate_id="ts", source_id="s",
                  raw_text="хочу научиться таро, я новичок, посоветуйте курс")
    r = jm.judge(c)  # офлайн: одна ступень mock, без эскалации
    assert r.decision is not None


def test_cloudru_config_defaults():
    from config import CONFIG
    assert CONFIG.llm_base_url.startswith("https://foundation-models.api.cloud.ru")
    assert "/" in CONFIG.router_model           # формат vendor/model
    assert CONFIG.rerank_model == "BAAI/bge-reranker-v2-m3"


def test_router_intents():
    from hermes import router
    assert router.route("придумай идеи для постов на молодых мам")["intent"] == "generate_content"
    assert router.route("какие у нас курсы и цены?")["intent"] == "ask_kb"
    assert router.route("найди учеников, кто хочет учиться таро")["intent"] == "search_leads"


def test_content_ideas_generated():
    from hermes.content_engine import generate_content_ideas
    r = generate_content_ideas("молодые мамы, саморазвитие")
    assert "ideas" in r and isinstance(r["ideas"], list)
    assert len(r["ideas"]) >= 1
    # все идеи прошли safety и не ссылаются на несуществующие продукты
    from hermes.knowledge_base import get_kb
    known = get_kb().known_product_ids()
    for idea in r["ideas"]:
        assert idea.get("safety") == "pass"
        pid = idea.get("uses_product_id")
        assert pid is None or pid in known


def test_content_ideas_safety_blocks_promises():
    # идея с обещанием результата должна отсекаться Safety на этапе фильтра
    from hermes.safety import check_message
    assert check_message("Гарантирую богатство за неделю!").verdict == "block"


def test_kb_answer_grounded():
    from hermes.kb_engine import answer_kb
    ans = answer_kb("какие курсы есть?")
    assert isinstance(ans, str) and len(ans) > 0
