"""Запуск тестов без pytest: python tests/run.py
(pytest-фикстуры не используются; env задаётся здесь.)"""
import importlib.util, os, sys, traceback, tempfile

tmp = tempfile.mkdtemp()
os.environ["HERMES_DB_PATH"] = os.path.join(tmp, "t.db")
os.environ["HERMES_EVENTS_PATH"] = os.path.join(tmp, "t.jsonl")
os.environ["LLM_PROVIDER"] = "mock"
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

ok = bad = 0
for fname in ["test_pipeline.py", "test_modules.py"]:
    spec = importlib.util.spec_from_file_location(fname[:-3], os.path.join(os.path.dirname(__file__), fname))
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    for name in [n for n in dir(m) if n.startswith("test_")]:
        # сбрасываем БД/события между тестами для изоляции
        for p in (os.environ["HERMES_DB_PATH"], os.environ["HERMES_EVENTS_PATH"]):
            try: os.remove(p)
            except OSError: pass
        try:
            getattr(m, name)(); print("PASS", fname, name); ok += 1
        except Exception as e:
            print("FAIL", fname, name, "->", e); traceback.print_exc(); bad += 1
print(f"\n{ok} passed, {bad} failed")
sys.exit(1 if bad else 0)
