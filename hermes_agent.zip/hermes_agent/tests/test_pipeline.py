"""Офлайн-тесты pipeline и ключевых инвариантов отбора."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from hermes import pipeline
from hermes.models import Decision
from hermes.safety import check_message
from hermes.judge import judge
from hermes.models import Candidate


def test_pipeline_runs_and_buckets():
    res = pipeline.run("хочу научиться таро", generate_messages=True)
    assert res.found >= 1
    # Все кандидаты распределены по корзинам
    assert res.found == res.after_rerank + 0 or res.after_rerank <= res.found
    total = len(res.passed) + len(res.review) + len(res.rejected)
    assert total >= 1


def test_expert_is_not_passed():
    c = Candidate(candidate_id="t_expert", source_id="x",
                  raw_text="Провожу консультации по таро, набор в мою группу, мои услуги, опыт 10 лет")
    r = judge(c)
    assert r.decision != Decision.PASS
    assert r.expert_risk_score > 0


def test_minor_rejected():
    c = Candidate(candidate_id="t_minor", source_id="x",
                  raw_text="Мне 16, интересно таро")
    r = judge(c)
    assert r.decision == Decision.REJECT
    assert "minor" in r.reason_tags


def test_safety_blocks_promise_and_price():
    assert check_message("Гарантирую результат за 5000 руб").verdict == "block"
    assert check_message("Здравствуйте! Расскажу про обучение, детали на darangel.ru").verdict == "pass"


def test_beginner_passes():
    c = Candidate(candidate_id="t_begin", source_id="x",
                  raw_text="Хочу научиться таро, я новичок, с чего начать, посоветуйте школу")
    r = judge(c)
    assert r.fit_score >= 0.4
