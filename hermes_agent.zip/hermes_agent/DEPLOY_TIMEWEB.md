# Деплой Hermes на Timeweb (VPS)

Пошагово, для запуска агента в production на российском хостинге Timeweb.

## 1. Создать VPS
- Timeweb Cloud → «Облачные серверы» → создать сервер (Ubuntu 22.04/24.04, 1–2 vCPU, 2 ГБ RAM достаточно для старта).
- Оплата российской картой.
- Зайти по SSH: `ssh root@<ip-сервера>`.

## 2. Установить Docker
```bash
apt update && apt install -y docker.io docker-compose-plugin git
systemctl enable --now docker
```

## 3. Загрузить проект
Скопируйте папку `hermes_agent` на сервер (через `scp` или git):
```bash
scp -r hermes_agent root@<ip>:/opt/hermes
# или: git clone <ваш-репозиторий> /opt/hermes
cd /opt/hermes
```

## 4. Настроить .env
```bash
cp .env.example .env
nano .env
```
Заполните минимум:
- `LLM_PROVIDER=openai` (или `anthropic`) и соответствующий ключ;
- `VK_ACCESS_TOKEN` — токен сообщества/пользователя VK для поиска;
- `TELEGRAM_BOT_TOKEN` — токен бота от @BotFather;
- `DARYA_CHAT_ID` — chat_id Дарьи (узнать через @userinfobot);
- `COHERE_API_KEY` — опционально, для качественного реранка.
`DATABASE_URL` в Docker-режиме подставляется автоматически (Postgres из compose).

## 5. Запустить
```bash
docker compose up -d --build
docker compose logs -f hermes-scheduler   # проверить, что поиск идёт
docker compose logs -f hermes-bot         # проверить бота
```
- `hermes-scheduler` — ищет лидов по расписанию (по умолчанию каждые 6 часов).
- `hermes-bot` — Telegram-бот: команда `/search <запрос>`, карточки кандидатов с кнопками фидбэка.
- `db` — PostgreSQL с сохранением состояния (том `hermes_pgdata`).

## 6. Управление
```bash
docker compose restart hermes-scheduler   # перезапуск
docker compose down                       # остановить всё
docker compose pull && docker compose up -d --build   # обновление
```

## 7. Расписание поиска
Интервал задаётся в `docker-compose.yml` (`loop 21600` = 6 часов).
Для другого интервала измените число секунд и `docker compose up -d`.
Альтернатива без Docker — systemd timer, вызывающий `python -m hermes sweep`.

## 8. Остановить старый бот
Не забудьте отключить прежний бот (тот, что парсил каждые 6 часов нецелевых),
чтобы он не дублировал работу и не тратил ресурс. См. Шаг 0 плана внедрения.

## 9. Обновление Knowledge Base
При изменении офферов на сайте:
```bash
docker compose run --rm hermes-bot python tools_kb_parser.py --write
docker compose restart hermes-scheduler hermes-bot
```

## Безопасность
- Сообщения уходят кандидату ТОЛЬКО после подтверждения Дарьи (human-in-the-loop).
- Соблюдайте лимиты VK и правила площадок (anti-spam в Safety Layer).
- Не таргетируйте аудиторию младше 18 (Judge + Safety это отсекают).
