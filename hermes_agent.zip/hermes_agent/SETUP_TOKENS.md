# Получение ключей для Hermes (VK, Telegram, LLM)

Заполняются в файле `.env`. Без них агент работает офлайн на mock-провайдере; с ними — «вживую».

---

## 1. Telegram-бот (TELEGRAM_BOT_TOKEN, DARYA_CHAT_ID)

**Токен бота:**
1. В Telegram найдите **@BotFather** → отправьте `/newbot`.
2. Задайте имя и username (должен заканчиваться на `bot`).
3. BotFather пришлёт строку вида `1234567890:AAH...` — это `TELEGRAM_BOT_TOKEN`.

**chat_id Дарьи (куда слать карточки кандидатов):**
- Простой способ: Дарья пишет любому боту **@userinfobot** — он покажет её `Id` (число) → это `DARYA_CHAT_ID`.
- Альтернатива: Дарья пишет вашему боту, затем откройте
  `https://api.telegram.org/bot<ТОКЕН>/getUpdates` — в ответе найдите `chat.id`.

> Важно: Дарья должна сама один раз написать боту `/start`, иначе бот не сможет ей писать.

---

## 2. VK API (VK_ACCESS_TOKEN)

Для поиска постов методом `newsfeed.search` нужен **пользовательский токен** (не токен сообщества).

**Способ A — через своё приложение (Implicit Flow), рекомендуется:**
1. Зайдите на **dev.vk.com** → «Мои приложения» → «Создать приложение» → тип **Standalone** (для ПК).
2. Скопируйте **ID приложения** (client_id).
3. Откройте в браузере ссылку (подставьте свой `CLIENT_ID`):
   ```
   https://oauth.vk.com/authorize?client_id=CLIENT_ID&display=page&redirect_uri=https://oauth.vk.com/blank.html&scope=wall,offline&response_type=token&v=5.199
   ```
4. Подтвердите доступ. После редиректа в адресной строке будет
   `https://oauth.vk.com/blank.html#access_token=vk1.a.XXXX&expires_in=0&user_id=...`.
5. Скопируйте значение `access_token` (`vk1.a....`) → это `VK_ACCESS_TOKEN`.
   `scope=offline` делает токен бессрочным.

**Способ B — токен сообщества (если ищете в рамках своей группы):**
Сообщество → Управление → Работа с API → Ключи доступа → Создать ключ.
Подходит для работы со своей группой, но `newsfeed.search` по всей сети им недоступен — используйте Способ A.

**Важно и по правилам:**
- Соблюдайте лимиты VK (несколько запросов в секунду) и правила платформы; не рассылайте спам.
- Первое сообщение кандидату Hermes отправляет только после подтверждения Дарьи (human-in-the-loop).
- Токен — секрет: храните только в `.env`, не коммитьте в git.

---

## 3. LLM (OPENAI_API_KEY или ANTHROPIC_API_KEY)

- OpenAI: platform.openai.com → API keys → Create. В `.env`: `LLM_PROVIDER=openai`, `OPENAI_API_KEY=sk-...`.
- Anthropic: console.anthropic.com → API keys. В `.env`: `LLM_PROVIDER=anthropic`, `ANTHROPIC_API_KEY=...`.
- Оплата зарубежных LLM российской картой может не проходить — как вариант используйте
  доступного провайдера или совместимый прокси-эндпоинт (тогда задайте base_url в `hermes/llm.py`).

---

## 4. Cohere (COHERE_API_KEY) — опционально
Для качественного реранка: dashboard.cohere.com → API Keys. Без него работает встроенный
сигнальный реранкер (бесплатно, но проще).

---

## Проверка
После заполнения `.env`:
```bash
python -m hermes kb         # KB читается
python -m hermes search "хочу научиться таро"   # с ключами — реальный поиск/оценка
python -m hermes bot        # запустить Telegram-бота, написать ему /search таро
```
