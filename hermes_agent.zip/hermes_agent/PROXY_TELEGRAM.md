# Telegram через прокси (если api.telegram.org заблокирован с сервера)

Симптом: `hermes-bot` в `Restarting`, в логах `telegram.error.TimedOut`, а
`curl https://api.telegram.org/` даёт `HTTP 000`. Значит сервер не достаёт Telegram напрямую.
Решение — пустить бота через твой VLESS-сервер (Aeza) как SOCKS5-прокси.

## Шаги (выполнять в папке ~/hermes-agent/hermes_agent)

1. Создай xray-конфиг из своей VLESS-ссылки (ссылка остаётся только на сервере):
   ```
   python3 tools_vless_proxy.py
   ```
   Вставь `vless://...`, Enter. Появится `xray-config.json`.

2. Пропиши прокси в .env:
   ```
   sed -i 's#^TELEGRAM_PROXY=.*#TELEGRAM_PROXY=socks5h://xray:1080#' .env
   ```

3. Запусти всё вместе с прокси-сервисом:
   ```
   sudo docker compose -f docker-compose.yml -f docker-compose.proxy.yml up -d --build
   ```

4. Проверь, что прокси добивает до Telegram:
   ```
   sudo docker compose -f docker-compose.yml -f docker-compose.proxy.yml exec xray \
     sh -c "apk add --no-cache curl >/dev/null 2>&1; curl -s --max-time 30 -x socks5h://127.0.0.1:1080 -o /dev/null -w 'через прокси: HTTP %{http_code}\n' https://api.telegram.org/"
   ```
   Ожидаем HTTP 302/200. Затем логи бота:
   ```
   sudo docker compose logs --tail 20 hermes-bot
   ```
   Должно быть «Telegram через прокси: ...» и запуск без TimedOut.
