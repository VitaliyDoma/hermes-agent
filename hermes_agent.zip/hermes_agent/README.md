# Hermes v3 — DarAngel Lead Agent

Мультиагентная система поиска **тёплых лидов-учеников** на курсы по эзотерике Дарьи Домаевой
(бренд DarAngel, `darangel.ru`). Цель отбора — именно **ученики**, а не эксперты, продавцы,
конкуренты или партнёры.

Полноценный, запускаемый агент: реальная Knowledge Base (распарсена с `darangel.ru`),
пайплайн отбора `search → rerank → judge → message → safety`, обучение на фидбэке,
Telegram-интерфейс, скедьюлер, PostgreSQL и Docker-деплой на Timeweb.
Работает **офлайн** на встроенном MockProvider; с ключами подключает реальные LLM/VK/Telegram/Cohere.

## Модули

| Модуль | Файл | Слой |
|--------|------|------|
| M1 Conversational Router | `hermes/router.py` | Conversational |
| M2 Candidate Search (VK) + гипотезы источников | `hermes/search_vk.py`, `hermes/sources.py` | Action |
| M3 Reranker (Cohere) | `hermes/reranker.py` | Action |
| M4 Lead Judge (scoring rubric) | `hermes/judge.py` | Action |
| M5 Message Generator | `hermes/message_engine.py` | Action |
| M6 Learning Loop | `hermes/learning_loop.py` | Learning |
| M7 Knowledge Base + парсер сайта | `hermes/knowledge_base.py`, `tools_kb_parser.py` | Knowledge |
| M8 Safety Layer | `hermes/safety.py` | Safety |
| M9 State Storage (SQLite/PostgreSQL) + события | `hermes/storage.py`, `hermes/events.py` | Infra |
| M10 Telegram Bot | `hermes/telegram_bot.py` | Conversational |
| Оркестратор / Скедьюлер | `hermes/pipeline.py`, `hermes/scheduler.py` | — |

## Быстрый старт (офлайн, без ключей)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # LLM_PROVIDER=mock по умолчанию
python -m hermes demo           # офлайн-демо пайплайна
python -m hermes kb             # показать Knowledge Base (продукты/услуги/направления)
python -m hermes search "хочу научиться таро"
python -m hermes sweep          # проход по гипотезам источников (data/sources.json)
python -m pytest -q             # тесты (или: python tests/run.py)
```

## CLI

```
python -m hermes demo            — офлайн-демо
python -m hermes search <запрос> — один поиск + отбор
python -m hermes sweep           — проход по всем гипотезам источников
python -m hermes bot             — Telegram-бот (нужен TELEGRAM_BOT_TOKEN)
python -m hermes kb              — показать Knowledge Base
```

## Включение реальных сервисов
В `.env`: `LLM_PROVIDER=openai`(+ключ), `VK_ACCESS_TOKEN`, `TELEGRAM_BOT_TOKEN`, `DARYA_CHAT_ID`,
опц. `COHERE_API_KEY`. Обновить базу знаний с сайта:
```bash
pip install requests beautifulsoup4
python tools_kb_parser.py            # показать найденное
python tools_kb_parser.py --write    # обновить data/knowledge_base.json
```

## Деплой на Timeweb
См. `DEPLOY_TIMEWEB.md`. Кратко: VPS + Docker, `docker compose up -d --build`
(поднимает Postgres, скедьюлер поиска и Telegram-бота).

## Knowledge Base (актуально на 2026-06-15)
- 3 обучающих продукта: Курс по Таро «От новичка до мастера за 4 месяца», Онлайн-марафон
  «Трансформация» (22 дня), Практический курс «Магия Рода».
- 12 услуг-раскладов, магазин «Лавка Чудес».
- Направления: Таро, Нумерология, Матрица Судьбы, Чакры, Свечная магия, Магия Рода, Руны.

## Безопасность отбора
- Только продукты/цены/даты из Knowledge Base (никаких выдумок) — `safety.py`.
- Не таргетировать аудиторию младше 18 — Judge + Safety отклоняют.
- Сообщения уходят кандидату **только после подтверждения Дарьи** (human-in-the-loop).

## KPI-дашборд
```bash
python -m hermes sweep        # накопить события
python -m hermes dashboard    # сгенерировать dashboard.html (KPI + графики)
```
`dashboard.html` — самодостаточная страница: воронка решений Judge, нагрузка по модулям,
warm-lead rate, false-positive rate, feedback coverage, run success rate.

## Ключи и токены
См. `SETUP_TOKENS.md` — пошагово VK access token, Telegram bot token + chat_id, LLM, Cohere.

## Тесты и CI
```bash
pytest -q            # 16 тестов (или: python tests/run.py — без pytest)
```
GitHub Actions (`.github/workflows/ci.yml`) гоняет тесты офлайн на каждый push/PR.

## Новое (v0.2): естественный диалог + вирусный контент

**Общение по-русски (M1 в Telegram).** Дарья пишет боту обычными словами — агент сам
определяет намерение (через M1 Router) и при необходимости задаёт наводящий вопрос.
Команды больше не нужны. Примеры:
- «найди учеников, которые хотят научиться таро» → поиск лидов;
- «придумай идеи для постов на молодых мам, интересующихся саморазвитием» → идеи контента;
- «какие у нас курсы и цены?» → ответ из базы знаний.

**M11 — генератор вирусных контент-идей** (`hermes/content_engine.py`, `hermes/trends.py`).
По заданной аудитории собирает актуальные тренды (реальные посты VK при наличии `VK_ACCESS_TOKEN`,
иначе — на знаниях модели) и выдаёт 5 идей контента (хук, формат, площадка, призыв, хэштеги,
почему «зайдёт»), привязанных к реальным продуктам из KB и проверенных Safety.
CLI: `python -m hermes content "<аудитория>"`, `python -m hermes ask "<вопрос>"`.

**Стабильность.** `docker-compose.yml` ждёт готовности БД (healthcheck), скедьюлер
повторяет проход через 30с при сбое — корректная работа после перезагрузки сервера.

## Обновление развёрнутого агента (с сохранением .env)
```bash
cd ~ && cp hermes-agent/hermes_agent/.env /tmp/hermes.env.bak \
  && rm -rf hermes-agent && git clone https://github.com/VitaliyDoma/hermes-agent.git \
  && cd hermes-agent && unzip -o hermes_agent.zip && cd hermes_agent \
  && cp /tmp/hermes.env.bak .env && sudo docker compose up -d --build
```
