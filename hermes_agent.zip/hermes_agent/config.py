"""Конфигурация Hermes. Читает .env, даёт безопасные дефолты для офлайн-запуска.

Провайдер по умолчанию — mock (офлайн). Для боевого режима на Cloud.ru:
  LLM_PROVIDER=cloudru, LLM_BASE_URL=https://foundation-models.api.cloud.ru/v1,
  LLM_API_KEY=<ключ сервисного аккаунта Foundation Models>.
"""
from __future__ import annotations
import os
from dataclasses import dataclass

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass


def _f(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


@dataclass
class Config:
    # Провайдер: mock | cloudru | openai | anthropic
    llm_provider: str = os.getenv("LLM_PROVIDER", "mock")
    llm_base_url: str = os.getenv("LLM_BASE_URL", "https://foundation-models.api.cloud.ru/v1")
    llm_api_key: str = os.getenv("LLM_API_KEY", "") or os.getenv("OPENAI_API_KEY", "")
    anthropic_api_key: str = os.getenv("ANTHROPIC_API_KEY", "")

    # --- Тиринг моделей (Cloud.ru Foundation Models, OpenAI-совместимый формат "<vendor>/<model>") ---
    # Дешёвый тир: роутер и скрининг-ступень Judge
    router_model: str = os.getenv("ROUTER_MODEL", "ai-sage/GigaChat3-10B-A1.8B")
    judge_screen_model: str = os.getenv("JUDGE_SCREEN_MODEL", "ai-sage/GigaChat3-10B-A1.8B")
    # Сильный тир: спорные кейсы Judge, генерация сообщений, learning loop
    judge_strong_model: str = os.getenv("JUDGE_STRONG_MODEL", "openai/gpt-4.1")
    message_model: str = os.getenv("MESSAGE_MODEL", "GigaChat/GigaChat-2-Max")
    learning_model: str = os.getenv("LEARNING_MODEL", "openai/gpt-4.1")
    kb_model: str = os.getenv("KB_MODEL", "openai/gpt-4o-mini")
    # Реранкер (M3): дешёвый нативный реранкер Cloud.ru
    rerank_model: str = os.getenv("RERANK_MODEL", "BAAI/bge-reranker-v2-m3")

    # Совместимость со старым именем judge_model (= сильная модель)
    @property
    def judge_model(self) -> str:
        return self.judge_strong_model

    # Двухступенчатый Judge
    judge_two_stage: bool = os.getenv("JUDGE_TWO_STAGE", "true").lower() == "true"

    tavily_api_key: str = os.getenv("TAVILY_API_KEY", "")
    cohere_api_key: str = os.getenv("COHERE_API_KEY", "")
    vk_access_token: str = os.getenv("VK_ACCESS_TOKEN", "")
    telegram_bot_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    telegram_proxy: str = os.getenv("TELEGRAM_PROXY", "")  # socks5://user:pass@host:port или http://...
    darya_chat_id: str = os.getenv("DARYA_CHAT_ID", "")
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///hermes.db")

    # Пороги Judge (scoring rubric)
    judge_pass_fit: float = _f("JUDGE_PASS_FIT", 0.6)
    judge_pass_expert_risk_max: float = _f("JUDGE_PASS_EXPERT_RISK_MAX", 0.3)
    judge_review_fit_min: float = _f("JUDGE_REVIEW_FIT_MIN", 0.4)

    @property
    def offline(self) -> bool:
        if self.llm_provider == "mock":
            return True
        if self.llm_provider in ("cloudru", "openai") and not self.llm_api_key:
            return True
        if self.llm_provider == "anthropic" and not self.anthropic_api_key:
            return True
        return False


CONFIG = Config()
