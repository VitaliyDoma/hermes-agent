"""Парсер darangel.ru → обновление data/knowledge_base.json (M7).

Запуск (в вашей среде с доступом в интернет):
    pip install requests beautifulsoup4
    python tools_kb_parser.py            # покажет найденные продукты/услуги
    python tools_kb_parser.py --write    # обновит data/knowledge_base.json (products/services/last_parsed_at)

Скрипт мягкий: тянет главную и /services, извлекает карточки. Цены/даты НЕ выдумывает —
заполняет только то, что реально нашёл на сайте, остальное оставляет на ручную доводку.
"""
from __future__ import annotations
import argparse
import datetime as _dt
import json
import os
import re
import sys

BASE = "https://darangel.ru"
KB_PATH = os.path.join(os.path.dirname(__file__), "data", "knowledge_base.json")


def _get(url: str) -> str:
    import requests
    r = requests.get(url, timeout=20, headers={"User-Agent": "HermesKB/1.0"})
    r.raise_for_status()
    return r.text


def _slug_id(url: str, prefix: str) -> str:
    slug = url.rstrip("/").split("/")[-1]
    slug = re.sub(r"[^a-z0-9]+", "_", slug.lower())[:40]
    return f"{prefix}_{slug}"


def parse_products(html: str) -> list[dict]:
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, "html.parser")
    out = []
    # карточки «Актуальные предложения»: заголовок h3 + ссылка на /school/...
    for a in soup.select('a[href*="/school/"]'):
        href = a.get("href", "")
        if "?category" in href or not href:
            continue
        title = a.find_previous(["h3", "h2"])
        name = title.get_text(strip=True) if title else a.get_text(strip=True)[:80]
        if not name:
            continue
        out.append({
            "id": _slug_id(href, "p"),
            "name": name,
            "type": "курс/марафон",
            "status": "active",
            "description": a.get_text(strip=True)[:400],
            "source_url": href if href.startswith("http") else BASE + href,
            "confidence": "confirmed",
        })
    # дедуп по url
    seen, uniq = set(), []
    for p in out:
        if p["source_url"] in seen:
            continue
        seen.add(p["source_url"]); uniq.append(p)
    return uniq


def parse_services(html: str) -> list[dict]:
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, "html.parser")
    out, seen = [], set()
    for a in soup.select('a[href*="/services/"]'):
        href = a.get("href", "")
        if not href or href.endswith("/services"):
            continue
        title = a.find_previous(["h3", "h2"])
        name = title.get_text(strip=True) if title else ""
        if not name:
            continue
        url = href if href.startswith("http") else BASE + href
        if url in seen:
            continue
        seen.add(url)
        dur = re.search(r"(\d{2,3})\s*мин", a.find_parent().get_text() if a.find_parent() else "")
        out.append({
            "id": _slug_id(url, "s"),
            "name": name,
            "type": "консультация/услуга",
            "status": "active",
            "duration": (dur.group(0) if dur else ""),
            "url": url,
            "confidence": "confirmed",
        })
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--write", action="store_true", help="обновить data/knowledge_base.json")
    args = ap.parse_args()

    home = _get(BASE + "/")
    services_html = _get(BASE + "/services")
    products = parse_products(home)
    services = parse_services(services_html)

    print(f"Найдено продуктов: {len(products)}")
    for p in products:
        print("  -", p["name"], "->", p["source_url"])
    print(f"Найдено услуг: {len(services)}")
    for s in services:
        print("  -", s["name"], s.get("duration", ""))

    if args.write:
        with open(KB_PATH, encoding="utf-8") as f:
            kb = json.load(f)
        if products:
            kb["products"] = products
        if services:
            kb["services"] = services
        kb.setdefault("hallucination_guard", {})
        kb["hallucination_guard"]["known_products_count"] = len(products) or kb["hallucination_guard"].get("known_products_count", 0)
        kb["hallucination_guard"]["known_services_count"] = len(services) or kb["hallucination_guard"].get("known_services_count", 0)
        kb["hallucination_guard"]["last_parsed_at"] = _dt.date.today().isoformat()
        with open(KB_PATH, "w", encoding="utf-8") as f:
            json.dump(kb, f, ensure_ascii=False, indent=2)
        print(f"\nОбновлено: {KB_PATH}")


if __name__ == "__main__":
    main()
